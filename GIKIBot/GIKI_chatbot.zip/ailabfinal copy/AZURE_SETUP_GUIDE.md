# Azure App Registration Setup Guide
## GIKI Student Services Platform

### Step 1: Create Azure App Registration

1. **Go to Azure Portal**
   - Navigate to https://portal.azure.com
   - Sign in with your administrator account

2. **Create New App Registration**
   - Go to **Azure Active Directory** → **App registrations**
   - Click **+ New registration**
   - **Name**: `GIKI Student Services Platform`
   - **Supported account types**: `Accounts in any organizational directory (Any Azure AD directory - Multitenant)`
   - **Redirect URI**: Leave blank for now (we're using device code flow)
   - Click **Register**

3. **Note Down Important Values**
   - **Application (client) ID**: Copy this - you'll need it for `AZURE_CLIENT_ID`
   - **Directory (tenant) ID**: Note this for future reference

### Step 2: Configure Authentication

1. **Enable Device Code Flow**
   - Go to **Authentication** section
   - Under **Advanced settings**, set **Allow public client flows** to **Yes**
   - Click **Save**

### Step 3: Add API Permissions

#### Microsoft Graph Permissions (Required for Email/Calendar)

1. **Delegated Permissions** (For user-specific data)
   - Go to **API permissions** → **+ Add a permission**
   - Select **Microsoft Graph**
   - Select **Delegated permissions**
   - Add these permissions:
     - `User.Read` - Read user profile
     - `Mail.Read` - Read user's mail
     - `Mail.Send` - Send mail as user
     - `Calendar.Read` - Read calendar events
     - `Contacts.Read` - Read contacts
     - `User.Read.All` - Read all users' profiles (for faculty directory)
     - `Directory.Read.All` - Read directory data (for organization info)

2. **Application Permissions** (For admin features)
   - Select **Microsoft Graph** → **Application permissions**
   - Add these permissions:
     - `User.Read.All` - Read all user profiles
     - `Directory.Read.All` - Read directory data
     - `Mail.Read` - Read mail in all mailboxes (admin feature)

#### Additional Service Permissions

3. **SharePoint Permissions** (For document storage)
   - Add **SharePoint** permissions:
     - `Sites.Read.All` - Read all site collections
     - `Files.Read.All` - Read files in all site collections

4. **Teams Permissions** (For communication)
   - Add **Microsoft Teams** permissions:
     - `Chat.ReadBasic` - Read basic chat information
     - `Team.ReadBasic.All` - Read team information

### Step 4: Grant Admin Consent

1. **Grant Consent for Permissions**
   - In **API permissions**, click **Grant admin consent for [Your Organization]**
   - Click **Yes** to approve all permissions
   - Wait for the consent to be granted (green checkmarks appear)

### Step 5: Configure App Settings

1. **Set App as Public Client**
   - Go to **Authentication**
   - Under **Advanced settings**, ensure **Allow public client flows** is **Yes**
   - Click **Save**

2. **Configure Token Settings**
   - Go to **Token configuration**
   - Add optional claims if needed for user information

### Step 6: Update Application Configuration

1. **Update your app.py with the correct Client ID**
   ```python
   AZURE_CLIENT_ID = 'your-new-application-client-id-here'
   ```

2. **Test the Authentication**
   - Restart your Flask app
   - Go to http://localhost:9000/login
   - Test the device code flow

### Step 7: Verify Permissions Work

1. **Test Email Access**
   - After login, check: http://localhost:9000/api/outlook/status
   - Then test: http://localhost:9000/api/outlook/emails

2. **Test User Directory**
   - Create an endpoint to test user listing:
   ```python
   @app.route('/api/users')
   def list_users():
       # Test User.Read.All permission
   ```

### Step 8: Additional Services Setup

#### For Faculty Directory Service:
- Ensure `User.Read.All` permission is granted
- This allows reading all faculty profiles from Azure AD

#### For Student Information:
- Use `User.Read.All` to access student profiles
- Filter by department/role using Azure AD attributes

#### For Communication Services:
- `Mail.Send` for sending notifications
- `Chat.ReadBasic` for Teams integration
- `Calendar.Read` for scheduling

#### For Document Management:
- SharePoint integration for storing:
  - Assignment submissions
  - Faculty documents
  - Admin reports

### Step 9: Security Considerations

1. **Implement Proper Access Control**
   ```python
   @app.route('/api/admin/<path:path>')
   @admin_required  # Create this decorator
   def admin_only():
       # Admin-only endpoints
   ```

2. **Use Least Privilege Principle**
   - Only request permissions you actually need
   - Consider using separate app registrations for different services

3. **Token Management**
   - Implement token refresh logic
   - Store tokens securely in database
   - Handle token expiration gracefully

### Step 10: Testing Checklist

- [ ] User can authenticate via device code
- [ ] User can read their emails
- [ ] User can send emails
- [ ] Admin can read all user profiles
- [ ] Calendar access works
- [ ] Contacts are accessible
- [ ] SharePoint integration works (if needed)

### Troubleshooting

#### Common Issues:
1. **Consent not granted**: Ensure admin consent is given for all permissions
2. **Token expired**: Implement refresh token logic
3. **Insufficient permissions**: Check that required permissions are granted
4. **Multi-tenant issues**: Ensure app supports multi-tenant authentication

#### Debug Commands:
```bash
# Check current permissions
curl -X GET "https://graph.microsoft.com/v1.0/me" \
  -H "Authorization: Bearer YOUR_TOKEN"

# Test email access
curl -X GET "https://graph.microsoft.com/v1.0/me/messages" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Next Steps

After completing this setup:
1. Update your `.env` file with the new client ID
2. Test all integrations
3. Implement proper error handling
4. Add logging for debugging
5. Set up monitoring for API usage

This comprehensive setup will enable your GIKI Student Services Platform to:
- Connect students, faculty, and admin
- Provide email integration
- Enable user directory services
- Support document management
- Facilitate communication features
