# Google Maps Integration Guide for GIKI Campus Navigation

## Overview

This guide explains how to integrate Google Maps API into your GIKI Student Services Platform to replace the current Leaflet/OpenStreetMap implementation.

---

## Step 1: Obtain Google Maps API Key

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable these APIs:
   - Maps JavaScript API
   - Places API
   - Directions API
   - Geocoding API
4. Navigate to "Credentials"
5. Click "Create Credentials" → "API Key"
6. Copy your API key
7. **Important**: Restrict your API key:
   - Application restrictions: HTTP referrers
   - Add: `http://localhost:5000/*` and your production domain
   - API restrictions: Select only the 4 APIs listed above

## Step 2: Set Environment Variable

Add to your `.env` file or export:

```bash
export GOOGLE_MAPS_API_KEY="your_api_key_here"
```

---

## Step 3: Update navigation.html

Replace the Leaflet map section (around line 100-150) with Google Maps:

### HTML Changes

```html
<!-- Map Container -->
<div class="col-md-8">
    <div class="card">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0">
                <i class="fas fa-map me-2"></i>Campus Map
            </h5>
        </div>
        <div class="card-body p-0">
            <!-- Google Maps Container -->
            <div id="googleMap" style="height: 600px; width: 100%;"></div>
        </div>
    </div>
</div>
```

### JavaScript for Google Maps

Add this to the `<script>` section:

```javascript
let map;
let markers = [];
let directionsService;
let directionsRenderer;
let userMarker;
let autocomplete;

// GIKI Campus center coordinates
const GIKI_CENTER = { lat: 34.0514, lng: 72.4542 };

function initGoogleMap() {
    // Initialize map
    map = new google.maps.Map(document.getElementById('googleMap'), {
        center: GIKI_CENTER,
        zoom: 16,
        mapTypeId: 'hybrid',  // satellite view with labels
        mapTypeControl: true,
        streetViewControl: true,
        fullscreenControl: true,
        zoomControl: true,
        styles: [
            {
                featureType: 'poi',
                elementType: 'labels',
                stylers: [{ visibility: 'on' }]
            }
        ]
    });
    
    // Initialize directions service
    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({
        map: map,
        suppressMarkers: false,
        polylineOptions: {
            strokeColor: '#667eea',
            strokeWeight: 5
        }
    });
    
    // Load campus locations
    loadCampusLocations();
    
    // Initialize Places Autocomplete
    const input = document.getElementById('locationSearch');
    autocomplete = new google.maps.places.Autocomplete(input, {
        bounds: new google.maps.LatLngBounds(
            new google.maps.LatLng(34.0450, 72.4480),
            new google.maps.LatLng(34.0580, 72.4600)
        ),
        strictBounds: true,
        types: ['establishment']
    });
    
    autocomplete.addListener('place_changed', function() {
        const place = autocomplete.getPlace();
        if (place.geometry) {
            map.setCenter(place.geometry.location);
            map.setZoom(18);
            addMarker(place.geometry.location, place.name);
        }
    });
}

function loadCampusLocations() {
    // Fetch locations from API
    fetch('/api/search_location?q=all')
        .then(response => response.json())
        .then(data => {
            if (data.results &&Array.isArray(data.results)) {
                data.results.forEach(location => {
                    if (location.latitude && location.longitude) {
                        addLocationMarker(location);
                    }
                });
            }
        })
        .catch(error => console.error('Error loading locations:', error));
}

function addLocationMarker(location) {
    const position = {
        lat: parseFloat(location.latitude),
        lng: parseFloat(location.longitude)
    };
    
    // Custom marker icon based on category
    const icons = {
        'classroom': 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        'lab': 'https://maps.google.com/mapfiles/ms/icons/purple-dot.png',
        'office': 'https://maps.google.com/mapfiles/ms/icons/yellow-dot.png',
        'default': 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
    };
    
    const marker = new google.maps.Marker({
        position: position,
        map: map,
        title: location.name,
        icon: icons[location.category] || icons.default,
        animation: google.maps.Animation.DROP
    });
    
    // Info window
    const infoWindow = new google.maps.InfoWindow({
        content: `
            <div style="padding: 10px;">
                <h6>${location.name}</h6>
                <p class="mb-1"><strong>Building:</strong> ${location.building || 'N/A'}</p>
                <p class="mb-1"><strong>Category:</strong> ${location.category || 'N/A'}</p>
                <button class="btn btn-sm btn-primary mt-2" onclick="getDirectionsToLocation(${location.latitude}, ${location.longitude})">
                    <i class="fas fa-route me-1"></i>Get Directions
                </button>
                <button class="btn btn-sm btn-success mt-2" onclick="startARToLocation({latitude: ${location.latitude}, longitude: ${location.longitude}, name: '${location.name}'})">
                    <i class="fas fa-camera me-1"></i>AR Navigate
                </button>
            </div>
        `
    });
    
    marker.addListener('click', function() {
        infoWindow.open(map, marker);
    });
    
    markers.push(marker);
}

function addMarker(position, title) {
    const marker = new google.maps.Marker({
        position: position,
        map: map,
        title: title,
        animation: google.maps.Animation.BOUNCE
    });
    
    setTimeout(() => marker.setAnimation(null), 2000);
    markers.push(marker);
    return marker;
}

function getCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function(position) {
                const userPos = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                
                map.setCenter(userPos);
                map.setZoom(18);
                
                // Add/update user marker
                if (userMarker) {
                    userMarker.setPosition(userPos);
                } else {
                    userMarker = new google.maps.Marker({
                        position: userPos,
                        map: map,
                        title: 'Your Location',
                        icon: {
                            path: google.maps.SymbolPath.CIRCLE,
                            scale: 10,
                            fillColor: '#4285F4',
                            fillOpacity: 1,
                            strokeColor: 'white',
                            strokeWeight: 3
                        },
                        animation: google.maps.Animation.DROP
                    });
                }
                
                alert('Location found! Blue dot shows your current position.');
            },
            function(error) {
                alert('Error getting location: ' + error.message);
            },
            { enableHighAccuracy: true }
        );
    } else {
        alert('Geolocation is not supported by your browser');
    }
}

function getDirectionsToLocation(destLat, destLng) {
    if (!userMarker) {
        alert('Please get your current location first');
        getCurrentLocation();
        return;
    }
    
    const origin = userMarker.getPosition();
    const destination = { lat: destLat, lng: destLng };
    
    const request = {
        origin: origin,
        destination: destination,
        travelMode: google.maps.TravelMode.WALKING
    };
    
    directionsService.route(request, function(result, status) {
        if (status === 'OK') {
            directionsRenderer.setDirections(result);
            
            // Show directions panel
            const route = result.routes[0];
            const leg = route.legs[0];
            
            document.getElementById('directionsPanel').style.display = 'block';
            document.getElementById('directionsContent').innerHTML = `
                <div class="mb-3">
                    <strong>Distance:</strong> ${leg.distance.text}<br>
                    <strong>Duration:</strong> ${leg.duration.text}
                </div>
                <h6>Steps:</h6>
                <ol>
                    ${leg.steps.map(step => `
                        <li class="mb-2">
                            ${step.instructions}
                            <small class="text-muted">(${step.distance.text})</small>
                        </li>
                    `).join('')}
                </ol>
            `;
            
            // Scroll to directions
            document.getElementById('directionsPanel').scrollIntoView({ behavior: 'smooth' });
        } else {
            alert('Directions request failed: ' + status);
        }
    });
}

function startARToLocation(location) {
    // Use the enhanced AR navigation system
    window.arNavigation.start(location)
        .catch(error => {
            alert('Failed to start AR navigation: ' + error.message);
        });
}

// Search function
function searchLocation() {
    const query = document.getElementById('locationSearch').value;
    if (!query) return;
    
    fetch(`/api/search_location?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            displaySearchResults(data.results || []);
        })
        .catch(error => console.error('Search error:', error));
}

function displaySearchResults(results) {
    const container = document.getElementById('searchResults');
    
    if (results.length === 0) {
        container.innerHTML = '<div class="alert alert-warning">No locations found</div>';
        return;
    }
    
    container.innerHTML = `
        <div class="list-group">
            ${results.map(result => `
                <a href="#" class="list-group-item list-group-item-action" onclick="selectSearchResult(${result.latitude}, ${result.longitude}, '${result.name}'); return false;">
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1">${result.name}</h6>
                        <small>${result.category || ''}</small>
                    </div>
                    <small class="text-muted">${result.building || ''}</small>
                </a>
            `).join('')}
        </div>
    `;
}

function selectSearchResult(lat, lng, name) {
    const position = { lat: parseFloat(lat), lng: parseFloat(lng) };
    map.setCenter(position);
    map.setZoom(19);
    addMarker(position, name);
}

// Initialize when page loads
window.addEventListener('load', function() {
    // Load Google Maps script
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places&callback=initGoogleMap`;
    script.async = true;
    script.defer = true;
    document.head.appendChild(script);
});
```

---

## Step 4: Update app.py Route

Add this route to serve the API key to the template:

```python
@app.route('/navigation')
def navigation_page():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    google_maps_key = os.getenv('GOOGLE_MAPS_API_KEY', '')
    
    return render_template('navigation.html', 
                         user=user, 
                         google_maps_api_key=google_maps_key)
```

---

## Step 5: Update navigation.html Template

Add at the top of your JavaScript section:

```html
<script>
const GOOGLE_MAPS_API_KEY = "{{ google_maps_api_key }}";
</script>
```

---

## Features Included

### ✅ Interactive Map
- Hybrid view (satellite + labels)
- Campus-centered with appropriate zoom
- Custom styled for better visibility

### ✅ Location Markers
- Color-coded by category (classroom, lab, office)
- Clickable with info windows
- "Get Directions" and "AR Navigate" buttons

### ✅ Places Autocomplete
- Search box with autocomplete
- Restricted to GIKI campus area
- Instant suggestions as you type

### ✅ Directions
- Walking directions with turn-by-turn
- Visual route on map (purple polyline)
- Distance and duration display
- Detailed step-by-step instructions

### ✅ Current Location
- Blue dot showing user position
- High accuracy positioning
- One-click location access

### ✅ AR Integration
- Seamless handoff to AR navigation
- Passes location data to AR system

---

## Customization Options

### Map Styles

Change map appearance:

```javascript
styles: [
    // Hide unwanted features
    {
        featureType: 'poi.business',
        stylers: [{ visibility: 'off' }]
    },
    // Custom colors
    {
        featureType: 'road',
        elementType: 'geometry',
        stylers: [{ color: '#38414e' }]
    }
]
```

### Marker Icons

Use custom campus building icons:

```javascript
const customIcon = {
    url: '/static/images/campus-building-icon.png',
    scaledSize: new google.maps.Size(40, 40),
    origin: new google.maps.Point(0, 0),
    anchor: new google.maps.Point(20, 40)
};
```

### Indoor Maps

For supported buildings:

```javascript
map.setOptions({
    mapTypeControlOptions: {
        mapTypeIds: ['roadmap', 'satellite', 'hybrid', 'terrain']
    },
    indoorEnabled: true
});
```

---

## Testing

1. **Basic Map Load**: Visit `/navigation` - map should display centered on GIKI
2. **Search**: Type "Computer Lab" - should show autocomplete suggestions
3. **Markers**: Click campus location - info window should appear
4. **Directions**: Click "Get Current Location" then "Get Directions" on a marker
5. **AR Handoff**: Click "AR Navigate" - should launch AR navigation

---

## Troubleshooting

### Map Not Loading
- Check API key is correct
- Verify APIs are enabled in Google Cloud Console
- Check browser console for errors

### Markers Not Showing
- Verify location data has valid lat/lng
- Check marker icon URLs are accessible
- Ensure locations are within campus bounds

### Autocomplete Not Working
- Confirm Places API is enabled
- Check bounds are correctly set
- Verify input element ID matches

### Directions Failing
- Ensure Directions API is enabled
- Check Start/end coordinates are valid
- Verify travel mode is supported

---

## Cost Optimization

Google Maps API usage is free up to certain limits. To optimize:

1. **Restrict API Key**: Only allow necessary APIs
2. **Set HTTP Referrers**: Prevent unauthorized use
3. **Use Static Maps**: For previews where interactivity isn't needed
4. **Cache Results**: Store directions/geocoding results
5. **Monitor Usage**: Check Google Cloud Console regularly

**Current free tier limits:**
- Maps JavaScript API: $200 free credit/month (~28,000 map loads)
- Directions API: $200 credit/month (~40,000 requests)
- Places API: $200 credit/month (~17,000 requests)

---

## Benefits Over Leaflet

1. **Better Satellite Imagery**: High-resolution campus photos
2. **Places Autocomplete**: Smart location search
3. **Directions API**: Accurate walking directions
4. **Indoor Maps**: For supported buildings
5. **Street View**: Virtual campus tours
6. **Better Mobile Support**: Optimized touch controls
7. **Regular Updates**: Google keeps data current

---

## Next Steps

After implementing Google Maps:
1. Add custom campus building polygons
2. Integrate indoor floor plans
3. Add traffic layer for external routes
4. Create custom map themes (dark mode)
5. Add saved locations/favorites

---

Ready to integrate! Follow the steps above and your navigation will be powered by Google Maps.
