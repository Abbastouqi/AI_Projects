import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import os

def try_connect(user, host=None, password=None):
    try:
        kwargs = {
            'dbname': 'postgres',
            'user': user
        }
        if host:
            kwargs['host'] = host
        if password:
            kwargs['password'] = password
            
        print(f"Attempting connection with user={user}, host={host}...")
        conn = psycopg2.connect(**kwargs)
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        return conn
    except Exception as e:
        print(f"Failed: {e}")
        return None

def create_database():
    # Try different combinations
    conn = None
    
    # 1. Try current user, socket
    conn = try_connect(os.getenv('USER'))
    
    # 2. Try postgres user, socket
    if not conn:
        conn = try_connect('postgres')
        
    # 3. Try postgres user, localhost (if socket failed/not found)
    if not conn:
        conn = try_connect('postgres', 'localhost')

    if not conn:
        print("Could not connect to PostgreSQL. Please provide credentials.")
        return

    try:
        cur = conn.cursor()
        # Check if database exists
        cur.execute("SELECT 1 FROM pg_catalog.pg_database WHERE datname = 'giki_services'")
        exists = cur.fetchone()
        
        if not exists:
            print("Creating database giki_services...")
            cur.execute('CREATE DATABASE giki_services')
            print("Database created successfully.")
        else:
            print("Database giki_services already exists.")
            
        cur.close()
        conn.close()
    except Exception as e:
        print(f"Error during DB operations: {e}")

if __name__ == "__main__":
    create_database()
