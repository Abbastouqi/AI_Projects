#!/usr/bin/env python3
"""
GIKI Student Services Platform
A comprehensive student services platform with Outlook integration, complaint system,
interactive navigation, food ordering, and more.
"""

import os
import json
import asyncio
import subprocess
import signal
import base64
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any

# Fix for protobuf registration conflict
os.environ["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"] = "python"
# Force Torch to avoid TensorFlow dependency in transformers
os.environ["USE_TORCH"] = "1"

from dotenv import load_dotenv

load_dotenv()

import msal
import requests
from mistralai.client import MistralClient
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash, make_response
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import secrets
from functools import wraps
import time

# NEW: Import Flask-SocketIO for real-time chat
from flask_socketio import SocketIO

# NEW: Import our enhanced modules
from rag_system import EmailRAGSystem
from event_extractor import EventExtractor
from chat_system import ChatSystem, initialize_default_channels

def kill_processes_on_port(port):
    """Kill all processes running on the specified port"""
    try:
        # Find processes using the port
        result = subprocess.run(['lsof', '-ti', f':{port}'], 
                              capture_output=True, text=True)
        if result.stdout.strip():
            pids = result.stdout.strip().split('\n')
            for pid in pids:
                try:
                    os.kill(int(pid), signal.SIGTERM)
                    print(f"Killed process {pid} on port {port}")
                except ProcessLookupError:
                    pass  # Process already terminated
                except PermissionError:
                    print(f"Permission denied to kill process {pid}")
        else:
            print(f"No processes found on port {port}")
    except Exception as e:
        print(f"Error killing processes on port {port}: {e}")

# AI/ML Imports
from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage
# from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain_community.vectorstores import Chroma
# from langchain_community.embeddings import HuggingFaceEmbeddings
# from langchain.chains import RetrievalQA
# from langchain.docstore.document import Document
# from langchain.prompts import PromptTemplate
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def encode_image(image_path: str) -> str:
    """Encode an image file as base64 string for Mistral OCR."""
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")


# Initialize Flask App
app = Flask(__name__)
app.secret_key = secrets.token_hex(16)
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=24)
app.config["SESSION_TYPE"] = "filesystem"

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'postgresql://postgres@localhost/giki_services')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Microsoft Graph API Configuration
AZURE_CLIENT_ID = os.getenv('AZURE_CLIENT_ID', '4fcd1516-dcd5-4e11-aa97-07f230f30055')

# Groq API keys
# GROQ_API_KEY is used for complaint processing; GROQ_AGENT_API_KEY for the
# agentic helper. Both are read from environment variables so secrets are not
# hard-coded in the repository.
GROQ_API_KEY = os.getenv('GROQ_API_KEY', '')
GROQ_AGENT_API_KEY = os.getenv('GROQ_AGENT_API_KEY', GROQ_API_KEY)
AUTHORITY = "https://login.microsoftonline.com/common"
SCOPES = [
    "https://graph.microsoft.com/Mail.Read",
    "https://graph.microsoft.com/User.Read",
]

# Mistral OCR client (requires MISTRAL_API_KEY env var)
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY")
mistral_ocr_client: Optional[MistralClient] = None
if MISTRAL_API_KEY:
    try:
        mistral_ocr_client = MistralClient(api_key=MISTRAL_API_KEY)
        print("✅ Mistral OCR client initialized")
    except Exception as e:
        print(f"❌ Failed to initialize Mistral client: {e}")


# NEW: Initialize Flask-SocketIO for real-time chat
socketio = SocketIO(app, cors_allowed_origins="*")

# NEW: Initialize RAG System for intelligent email processing
rag_system = EmailRAGSystem(
    groq_api_key=GROQ_API_KEY,
    persist_directory="./chroma_db"
)

# NEW: Initialize Event Extractor for parsing events from emails
event_extractor = EventExtractor(groq_api_key=GROQ_API_KEY)

# NEW: Chat system will be initialized after database creation
chat_system = None
# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    roll_number = db.Column(db.String(20), unique=True, nullable=False)
    hostel = db.Column(db.String(50))
    room_number = db.Column(db.String(20))
    phone = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    outlook_token = db.Column(db.Text)  # Store Outlook access token

class Complaint(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    subcategory = db.Column(db.String(100))
    description = db.Column(db.Text, nullable=False)
    urgency = db.Column(db.String(20), default='medium')
    status = db.Column(db.String(20), default='pending')
    assigned_to = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime)
    user = db.relationship('User', backref=db.backref('complaints', lazy=True))

class DepartmentContact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    designation = db.Column(db.String(100))
    email = db.Column(db.String(120))
    phone = db.Column(db.String(20))
    office_location = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)

class CampusLocation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50))  # classroom, lab, hall, office, etc.
    building = db.Column(db.String(50))
    floor = db.Column(db.String(10))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    description = db.Column(db.Text)
    keywords = db.Column(db.Text)  # JSON array of search keywords

class Restaurant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50))  # mess, cafe, tuc, etc.
    location = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, default=True)
    menu_items = db.relationship('MenuItem', backref='restaurant', lazy=True)

class MenuItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurant.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50))
    is_available = db.Column(db.Boolean, default=True)
    preparation_time = db.Column(db.Integer)  # minutes

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurant.id'), nullable=False)
    items = db.Column(db.Text)  # JSON of order items
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')
    delivery_location = db.Column(db.String(100))
    special_instructions = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    estimated_delivery = db.Column(db.DateTime)
    user = db.relationship('User', backref=db.backref('orders', lazy=True))
    restaurant = db.relationship('Restaurant', backref=db.backref('orders', lazy=True))


class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    from_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    to_user_id = db.Column(db.Integer, db.ForeignKey('user.id'))  # optional specific recipient
    from_role = db.Column(db.String(20))  # e.g., student, faculty, admin, developer
    to_role = db.Column(db.String(20))
    channel = db.Column(db.String(50))  # e.g., student-faculty, student-admin
    content = db.Column(db.Text, nullable=False)
    source = db.Column(db.String(20), default='text')  # text or ocr
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    from_user = db.relationship('User', foreign_keys=[from_user_id], backref=db.backref('feedback_sent', lazy=True))
    to_user = db.relationship('User', foreign_keys=[to_user_id], backref=db.backref('feedback_received', lazy=True))


# New Models for Chat System
class ChatChannel(db.Model):
    """Chat channels for different communication types."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    channel_type = db.Column(db.String(50), nullable=False)  # student-student, student-faculty, etc.
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    messages = db.relationship('ChatMessage', backref='channel', lazy=True, cascade='all, delete-orphan')


class ChatMessage(db.Model):
    """Messages in chat channels."""
    id = db.Column(db.Integer, primary_key=True)
    channel_id = db.Column(db.Integer, db.ForeignKey('chat_channel.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    message_type = db.Column(db.String(20), default='text')  # text, image, file
    attachment_url = db.Column(db.String(500))
    is_edited = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    edited_at = db.Column(db.DateTime)
    user = db.relationship('User', backref=db.backref('chat_messages', lazy=True))


# New Model for Events
class Event(db.Model):
    """Events extracted from emails (seminars, concerts, workshops, etc.)."""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    event_type = db.Column(db.String(50))  # seminar, workshop, concert, etc.
    description = db.Column(db.Text)
    date = db.Column(db.String(50))  # Store as string initially (could be parsed date)
    time = db.Column(db.String(50))
    location = db.Column(db.String(200))
    organizer = db.Column(db.String(200))
    source_email_id = db.Column(db.String(200))  # Outlook email ID
    source_email_subject = db.Column(db.String(500))
    registration_required = db.Column(db.Boolean, default=False)
    extraction_method = db.Column(db.String(50))  # llm or pattern_matching
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    extracted_at = db.Column(db.String(100))  # ISO format timestamp from extractor


# Enhanced Outlook Manager
class EnhancedOutlookManager:
    def __init__(self, client_id: str, scopes: List[str]):
        self.client_id = client_id
        self.scopes = scopes
        self.access_token = None
        self.refresh_token = None
        self.app = None

    def authenticate(self, token_cache=None):
        """Authenticate using device code flow"""
        self.app = msal.PublicClientApplication(
            self.client_id,
            authority=AUTHORITY,
            token_cache=token_cache
        )

        flow = self.app.initiate_device_flow(scopes=self.scopes)
        if "user_code" not in flow:
            raise ValueError("Failed to create device flow")

        return flow

    def acquire_token_by_device_flow(self, flow):
        """Complete device flow authentication with timeout"""
        import time
        start_time = time.time()
        timeout = 180  # 5 minutes timeout        """Complete device flow authentication"""
        result = self.app.acquire_token_by_device_flow(flow)
        if "access_token" in result:
            self.access_token = result["access_token"]
            self.refresh_token = result.get("refresh_token")
            return True
        return False

    def get_user_info(self) -> Dict:
        """Get current user information"""
        if not self.access_token:
            return None

        headers = {"Authorization": f"Bearer {self.access_token}"}
        response = requests.get("https://graph.microsoft.com/v1.0/me", headers=headers)
        
        if response.status_code == 200:
            return response.json()
        return None

    def get_emails(self, max_emails: int = 100, days_back: int = 30) -> List[Dict]:
        """Fetch emails with enhanced filtering"""
        if not self.access_token:
            print("No access token available")
            return []

        headers = {"Authorization": f"Bearer {self.access_token}"}
        start_date = (datetime.now() - timedelta(days=days_back)).isoformat() + "Z"

        url = "https://graph.microsoft.com/v1.0/me/messages"
        params = {
            "$top": max_emails,
            "$orderby": "receivedDateTime DESC",
            "$filter": f"receivedDateTime ge {start_date}",
            "$select": "subject,from,receivedDateTime,bodyPreview,body,isRead,hasAttachments,importance,cc,bcc"
        }

        try:
            response = requests.get(url, headers=headers, params=params)
            print(f"Email API response status: {response.status_code}")
            
            if response.status_code == 200:
                emails = response.json().get("value", [])
                print(f"Found {len(emails)} emails")
                return emails
            elif response.status_code == 401:
                print("Token expired or invalid")
                return []
            else:
                print(f"API Error: {response.status_code} - {response.text}")
                return []
        except Exception as e:
            print(f"Exception fetching emails: {e}")
            return []

    def send_email(self, to_recipients: List[str], subject: str, body: str, cc_recipients: List[str] = None) -> bool:
        """Send email via Graph API"""
        if not self.access_token:
            return False

        headers = {"Authorization": f"Bearer {self.access_token}", "Content-Type": "application/json"}
        
        email_data = {
            "message": {
                "subject": subject,
                "body": {"contentType": "Text", "content": body},
                "toRecipients": [{"emailAddress": {"address": email}} for email in to_recipients]
            }
        }
        
        if cc_recipients:
            email_data["message"]["ccRecipients"] = [{"emailAddress": {"address": email}} for email in cc_recipients]

        response = requests.post(
            "https://graph.microsoft.com/v1.0/me/sendMail",
            headers=headers,
            json=email_data
        )
        
        return response.status_code == 202

    def get_contacts(self) -> List[Dict]:
        """Get user contacts"""
        if not self.access_token:
            return []

        headers = {"Authorization": f"Bearer {self.access_token}"}
        response = requests.get("https://graph.microsoft.com/v1.0/me/contacts", headers=headers)
        
        if response.status_code == 200:
            return response.json().get("value", [])
        return []

    def get_calendar_events(self, days_ahead: int = 7) -> List[Dict]:
        """Get calendar events"""
        if not self.access_token:
            return []

        headers = {"Authorization": f"Bearer {self.access_token}"}
        end_date = (datetime.now() + timedelta(days=days_ahead)).isoformat() + "Z"
        
        url = "https://graph.microsoft.com/v1.0/me/events"
        params = {
            "$orderby": "start/dateTime ASC",
            "$filter": f"start/dateTime le {end_date}"
        }

        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            return response.json().get("value", [])
        return []

# Complaint Processing System
class ComplaintProcessor:
    def __init__(self, groq_api_key: str):
        try:
            self.llm = ChatGroq(
                groq_api_key=groq_api_key,
                model_name="llama-3.1-70b-versatile",
                temperature=0.1
            )
        except Exception as e:
            print(f"⚠️ Failed to initialize ComplaintProcessor LLM: {e}")
            self.llm = None
        
        # Initialize TF-IDF for categorization
        self.vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
        self.category_keywords = {
            'hostel': ['room', 'hostel', 'mess', 'food', 'water', 'electricity', 'plumbing', 'furniture'],
            'academic': ['course', 'teacher', 'exam', 'grade', 'assignment', 'lecture', 'class'],
            'internet': ['wifi', 'internet', 'network', 'connection', 'slow', 'speed'],
            'maintenance': ['repair', 'broken', 'damaged', 'maintenance', 'cleaning'],
            'administrative': ['fee', 'registration', 'document', 'certificate', 'office'],
            'security': ['security', 'safety', 'gate', 'entry', 'card', 'access']
        }

    def categorize_complaint(self, description: str) -> Dict:
        """Categorize complaint using TF-IDF and keyword matching"""
        # Preprocess
        text = description.lower()
        
        # Keyword matching
        category_scores = {}
        for category, keywords in self.category_keywords.items():
            score = sum(1 for keyword in keywords if keyword in text)
            category_scores[category] = score
        
        # Get best category
        best_category = max(category_scores, key=category_scores.get)
        confidence = category_scores[best_category] / len(self.category_keywords[best_category])
        
        # Use LLM for better categorization if confidence is low
        if confidence < 0.3 and self.llm:
            prompt = f"""
            Categorize this student complaint into one of these categories: 
            hostel, academic, internet, maintenance, administrative, security
            
            Complaint: {description}
            
            Respond with JSON format: {{"category": "category_name", "subcategory": "specific_issue", "urgency": "low/medium/high"}}
            """
            
            try:
                response = self.llm.invoke([HumanMessage(content=prompt)])
                import re
                json_match = re.search(r'\{.*\}', response.content, re.DOTALL)
                if json_match:
                    llm_result = json.loads(json_match.group())
                    best_category = llm_result.get('category', best_category)
                    confidence = 0.8
            except:
                pass
        
        return {
            'category': best_category,
            'confidence': confidence,
            'urgency': self._assess_urgency(description)
        }

    def _assess_urgency(self, description: str) -> str:
        """Assess complaint urgency"""
        urgent_keywords = ['urgent', 'emergency', 'immediately', 'critical', 'broken', 'no water', 'no electricity']
        text = description.lower()
        
        if any(keyword in text for keyword in urgent_keywords):
            return 'high'
        elif any(keyword in text for keyword in ['please', 'soon', 'asap']):
            return 'medium'
        else:
            return 'low'

    def find_relevant_contacts(self, category: str, subcategory: str = None) -> List[Dict]:
        """Find relevant department contacts for complaint"""
        contacts = DepartmentContact.query.filter_by(is_active=True).all()
        
        # Simple mapping - in production, this would be more sophisticated
        category_mapping = {
            'hostel': ['Hostel Warden', 'Mess Manager', 'Maintenance'],
            'academic': ['Academic Affairs', 'Department Head', 'Course Coordinator'],
            'internet': ['IT Department', 'Network Administrator'],
            'maintenance': ['Maintenance Department', 'Engineering Staff'],
            'administrative': ['Admin Office', 'Student Affairs', 'Registration'],
            'security': ['Security Office', 'Campus Security']
        }
        
        relevant_titles = category_mapping.get(category, ['Admin Office'])
        relevant_contacts = []
        
        for contact in contacts:
            if any(title.lower() in contact.designation.lower() for title in relevant_titles):
                relevant_contacts.append({
                    'name': contact.name,
                    'department': contact.department,
                    'designation': contact.designation,
                    'email': contact.email,
                    'phone': contact.phone,
                    'office_location': contact.office_location
                })
        
        return relevant_contacts


class AgenticHelper:
    """Agentic helper that suggests actions but never executes them.

    It uses Groq LLM (ChatGroq) to analyze the user's goal and the current
    app capabilities, then returns a JSON list of high-level actions for the
    frontend to show for approval.
    """

    def __init__(self, api_key: str | None, mistral_client=None):
        self.api_key = api_key
        self.llm = None
        self.mistral_client = mistral_client
        if api_key:
            try:
                self.llm = ChatGroq(
                    groq_api_key=api_key,
                    model_name="llama-3.1-70b-versatile",
                    temperature=0.2,
                )
            except Exception as e:
                print(f"Failed to initialize AgenticHelper ChatGroq LLM: {e}")

    def plan_actions(self, goal: str, context: Dict | None = None) -> Dict:
        """Return a JSON-safe structure describing proposed actions."""
        # Try LLM first (Groq or Mistral)
        if self.llm:
            try:
                return self._plan_with_groq(goal, context)
            except Exception as e:
                print(f"Groq planning failed, trying Mistral/Heuristics: {e}")
        
        if self.mistral_client:
            try:
                return self._plan_with_mistral(goal, context)
            except Exception as e:
                print(f"Mistral planning failed, trying Heuristics: {e}")

        # Fallback to heuristics
        return {
            "summary": f"I couldn't use the AI models, but here's a plan based on your goal: '{goal}'",
            "actions": self._heuristic_actions(goal),
        }

    def _plan_with_groq(self, goal: str, context: Dict | None = None) -> Dict:
        ctx = context or {}
        prompt = self._build_prompt(goal, ctx)
        
        from langchain_core.messages import HumanMessage
        response = self.llm.invoke([HumanMessage(content=prompt)])
        return self._parse_llm_response(response.content, goal)

    def _plan_with_mistral(self, goal: str, context: Dict | None = None) -> Dict:
        ctx = context or {}
        prompt = self._build_prompt(goal, ctx)
        
        # Using Mistral Chat Completion
        from mistralai.models.chat_completion import ChatMessage
        chat_response = self.mistral_client.chat(
            model="mistral-large-latest",
            messages=[ChatMessage(role="user", content=prompt)]
        )
        return self._parse_llm_response(chat_response.choices[0].message.content, goal)

    def _build_prompt(self, goal: str, context: Dict) -> str:
        return (
            "You are an assistant embedded inside the GIKI Student Services Platform.\n"
            "The user described this goal:\n" 
            f"GOAL: {goal}\n\n"
            "You must respond with a pure JSON object (no markdown) of the form:\n"
            "{\n"
            "  \"summary\": \"short natural language summary of what you propose\",\n"
            "  \"actions\": [\n"
            "    {\n"
            "      \"id\": \"unique_id\",\n"
            "      \"type\": \"api_call\" | \"navigation\" | \"email\" | \"feedback\" | \"ocr\" | \"other\",\n"
            "      \"endpoint\": \"/api/search_location\" | \"/api/complaint\" | \"/api/feedback\" | \"/api/feedback/ocr\" | \"/api/outlook/emails\" | \"/api/order\",\n"
            "      \"method\": \"GET\" | \"POST\" | \"PUT\" | \"DELETE\",\n"
            "      \"payload\": {\"example\": \"JSON payload\"},\n"
            "      \"description\": \"what this action will do\",\n"
            "      \"dangerous\": false\n"
            "    }\n"
            "  ]\n"
            "}\n\n"
            "CRITICAL RULES:\n"
            "1. For ANY goal related to finding a place, navigating, or going somewhere, use type='navigation' and endpoint='/api/search_location' with method='GET' and payload={'q': 'query'}.\n"
            "2. EVERY action MUST have a valid 'endpoint' and 'method' from the list above. Do NOT invent new ones.\n"
            "3. If multiple steps are needed (e.g., find lab then email faculty), provide multiple actions in the list.\n"
            f"Current lightweight context: {json.dumps(context)}\n"
        )


    def _parse_llm_response(self, text: str, goal: str) -> Dict:
        import json as _json
        import re as _re
        text = text.strip()
        plan = None
        try:
            plan = _json.loads(text)
        except Exception:
            m = _re.search(r"\{[\s\S]*\}", text)
            if m:
                plan = _json.loads(m.group(0))

        if not isinstance(plan, dict):
            raise ValueError("LLM did not return a JSON object")

        actions = plan.get("actions") or []
        if not actions:
            actions = self._heuristic_actions(goal)
            plan["actions"] = actions
            if "summary" not in plan:
                plan["summary"] = "Heuristic plan based on your goal."
        return plan


    def _heuristic_actions(self, goal: str) -> List[Dict]:
        """Very lightweight fallback planner for common intents.

        This runs if the LLM output can't be parsed or returns no actions.
        """
        goal_lower = (goal or "").lower()
        actions: List[Dict] = []

        # Navigation-related
        if any(w in goal_lower for w in ["navigate", "direction", "route", "lab", "lecture hall", "library"]):
            # Extract a naive query by removing generic words
            query = goal
            for word in ["help", "me", "find", "navigate", "directions", "direction", "show", "to", "from", "my", "location"]:
                query = query.replace(word, "")
                query = query.replace(word.capitalize(), "")
            query = query.strip() or "lab"

            actions.append({
                "id": "nav_search",
                "type": "navigation",
                "endpoint": "/api/search_location",
                "method": "GET",
                "payload": {"q": query},
                "description": f"Search for '{query}' in on-campus locations and external maps.",
                "dangerous": False,
            })

        # Complaint-related
        if "complaint" in goal_lower or "issue" in goal_lower:
            actions.append({
                "id": "draft_complaint",
                "type": "complaint",
                "endpoint": "/api/complaint",
                "method": "POST",
                "payload": {"description": goal},
                "description": "Draft and file a complaint using your goal text as the description.",
                "dangerous": True,
            })

        # Email-related
        if "email" in goal_lower or "mail" in goal_lower:
            actions.append({
                "id": "load_emails",
                "type": "email",
                "endpoint": "/api/outlook/emails",
                "method": "GET",
                "payload": {},
                "description": "Fetch recent Outlook emails so you can review them or draft a reply.",
                "dangerous": False,
            })

        return actions

# Campus Navigation System
class CampusNavigator:
    def __init__(self):
        self.locations = CampusLocation.query.all()
        
    def search_location(self, query: str) -> List[Dict]:
        """Search for campus locations using natural language.

        1) First try internal CampusLocation records.
        2) If no good matches, fall back to an external maps API
           (OpenStreetMap Nominatim) using the query plus a fixed
           GIKI-specific suffix so results stay within the campus vicinity.
        """
        query_lower = query.lower()
        
        # 1) Internal keyword-based search
        results: List[Dict] = []
        for location in self.locations:
            score = 0
            
            # Name matching
            if any(word in location.name.lower() for word in query_lower.split()):
                score += 3
            
            # Category matching
            if location.category and location.category.lower() in query_lower:
                score += 2
            
            # Keywords matching
            if location.keywords:
                try:
                    keywords = json.loads(location.keywords)
                except Exception:
                    keywords = []
                if any(keyword.lower() in query_lower for keyword in keywords):
                    score += 2
            
            # Building matching
            if location.building and any(word in location.building.lower() for word in query_lower.split()):
                score += 1
            
            if score > 0:
                results.append({
                    'id': location.id,
                    'name': location.name,
                    'category': location.category,
                    'building': location.building,
                    'floor': location.floor,
                    'latitude': location.latitude,
                    'longitude': location.longitude,
                    'description': location.description,
                    'score': score
                })
        
        # If we have good internal results, return top 5,
        # but refresh their coordinates using live geocoding so that
        # we are not dependent on any stale placeholder lat/lon.
        if results:
            results.sort(key=lambda x: x['score'], reverse=True)
            top = results[:5]
            for r in top:
                # Prefer building name for geocoding, fall back to location name
                base_name = r.get('building') or r.get('name')
                if not base_name:
                    continue
                lat, lon = geocode_giki_location(base_name)
                if lat is not None and lon is not None:
                    r['latitude'] = lat
                    r['longitude'] = lon
            return top

        # 2) Fallback: external maps API (OpenStreetMap Nominatim)
        # Try to infer a relevant building/faculty name from existing
        # CampusLocation records so that we always geocode something that we
        # know is on GIKI campus, instead of the raw free-form query.
        try:
            best_building = None
            best_building_score = 0
            q_words = query_lower.split()

            for location in self.locations:
                score = 0
                # Match against location name
                if any(w in (location.name or "").lower() for w in q_words):
                    score += 2
                # Match against building name
                if location.building and any(w in location.building.lower() for w in q_words):
                    score += 3
                # Match against keywords JSON
                if location.keywords:
                    try:
                        kws = json.loads(location.keywords)
                    except Exception:
                        kws = []
                    if any(w in (" ".join(kws)).lower() for w in q_words):
                        score += 1
                if score > best_building_score and location.building:
                    best_building_score = score
                    best_building = location.building

            base_query = best_building if best_building else query
            giki_suffix = " in ghulam ishaq khan institute , topo district swabi , kpk"
            full_query = f"{base_query}{giki_suffix}"
            print(f"External maps search query: {full_query}")
            url = "https://nominatim.openstreetmap.org/search"
            params = {
                "q": full_query,
                "format": "json",
                "limit": 5,
            }
            headers = {
                "User-Agent": "giki-student-services-app/1.0 (education project)"
            }
            response = requests.get(url, params=params, headers=headers, timeout=5)
            if response.status_code == 200:
                data = response.json()
                ext_results: List[Dict] = []
                for item in data:
                    try:
                        lat = float(item.get("lat"))
                        lon = float(item.get("lon"))
                    except (TypeError, ValueError):
                        continue
                    ext_results.append({
                        'id': None,
                        'name': item.get("display_name", "Unknown location"),
                        'category': 'external',
                        'building': best_building,
                        'floor': None,
                        'latitude': lat,
                        'longitude': lon,
                        'description': item.get("display_name"),
                        'score': 1,
                    })
                return ext_results
        except Exception as e:
            print(f"External maps search failed: {e}")

        # Fallback: no results
        return []

    def get_directions(self, from_lat: float, from_lng: float, to_lat: float, to_lng: float) -> Dict:
        """Get directions between two points using OSRM road routing.

        Falls back to a simple straight-line estimate if the routing service
        is unavailable.
        """
        try:
            osrm_url = (
                f"https://router.project-osrm.org/route/v1/driving/"
                f"{from_lng},{from_lat};{to_lng},{to_lat}"
            )
            resp = requests.get(
                osrm_url,
                params={
                    "overview": "full",
                    "geometries": "geojson",
                },
                timeout=8,
            )
            if resp.status_code == 200:
                data = resp.json()
                routes = data.get("routes") or []
                if routes:
                    route = routes[0]
                    distance_km = (route.get("distance", 0) or 0) / 1000.0
                    duration_min = int((route.get("duration", 0) or 0) / 60.0)
                    geometry = route.get("geometry", {})
                    coords = geometry.get("coordinates", [])
                    # OSRM returns [lon, lat]; convert to [lat, lng]
                    polyline = [
                        {"lat": lat, "lng": lon}
                        for (lon, lat) in coords
                    ]
                    return {
                        "distance": distance_km,
                        "walking_time": duration_min,
                        "mode": "driving",
                        "polyline": polyline,
                        "steps": [
                            {
                                "instruction": "Follow the road route to your destination.",
                                "distance": distance_km,
                                "duration": duration_min,
                            }
                        ],
                    }
        except Exception as e:
            print(f"OSRM routing failed, falling back to straight-line: {e}")

        # Fallback: straight-line estimate
        distance = self._calculate_distance(from_lat, from_lng, to_lat, to_lng)
        walking_time = int((distance / 5) * 60)  # minutes, assuming 5 km/h
        return {
            "distance": distance,
            "walking_time": walking_time,
            "mode": "walking",
            "polyline": [
                {"lat": from_lat, "lng": from_lng},
                {"lat": to_lat, "lng": to_lng},
            ],
            "steps": [
                {
                    "instruction": f"Head towards {self._get_direction(from_lat, from_lng, to_lat, to_lng)}",
                    "distance": distance,
                    "duration": walking_time,
                }
            ],
        }

    def _calculate_distance(self, lat1: float, lng1: float, lat2: float, lng2: float) -> float:
        """Calculate distance between two coordinates"""
        from math import radians, cos, sin, asin, sqrt
        
        lat1, lng1, lat2, lng2 = map(radians, [lat1, lng1, lat2, lng2])
        dlat = lat2 - lat1
        dlng = lng2 - lng1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlng/2)**2
        c = 2 * asin(sqrt(a))
        km = 6371 * c
        return km

    def _get_direction(self, lat1: float, lng1: float, lat2: float, lng2: float) -> str:
        """Get cardinal direction between two points"""
        lat_diff = lat2 - lat1
        lng_diff = lng2 - lng1
        
        if abs(lat_diff) > abs(lng_diff):
            return 'north' if lat_diff > 0 else 'south'
        else:
            return 'east' if lng_diff > 0 else 'west'

# Food Ordering System
class FoodOrderingSystem:
    def __init__(self):
        self.restaurants = Restaurant.query.filter_by(is_active=True).all()
    
    def get_restaurants(self) -> List[Dict]:
        """Get all active restaurants"""
        return [
            {
                'id': r.id,
                'name': r.name,
                'category': r.category,
                'location': r.location,
                'phone': r.phone
            }
            for r in self.restaurants
        ]
    
    def get_menu(self, restaurant_id: int) -> List[Dict]:
        """Get menu for a specific restaurant"""
        restaurant = Restaurant.query.get(restaurant_id)
        if not restaurant:
            return []
        
        return [
            {
                'id': item.id,
                'name': item.name,
                'description': item.description,
                'price': item.price,
                'category': item.category,
                'is_available': item.is_available,
                'preparation_time': item.preparation_time
            }
            for item in restaurant.menu_items
            if item.is_available
        ]
    
    def create_order(self, user_id: int, restaurant_id: int, items: List[Dict], 
                    delivery_location: str = None, special_instructions: str = None) -> Dict:
        """Create a new order"""
        restaurant = Restaurant.query.get(restaurant_id)
        if not restaurant:
            return {'error': 'Restaurant not found'}
        
        # Calculate total and validate items
        total = 0
        valid_items = []
        
        for item_data in items:
            menu_item = MenuItem.query.get(item_data['id'])
            if menu_item and menu_item.is_available:
                total += menu_item.price * item_data['quantity']
                valid_items.append({
                    'id': menu_item.id,
                    'name': menu_item.name,
                    'price': menu_item.price,
                    'quantity': item_data['quantity']
                })
        
        if not valid_items:
            return {'error': 'No valid items in order'}
        
        # Estimate delivery time
        max_prep_time = max(MenuItem.query.get(item['id']).preparation_time or 15 for item in valid_items)
        estimated_delivery = datetime.now() + timedelta(minutes=max_prep_time + 10)  # 10 mins for delivery
        
        # Create order
        order = Order(
            user_id=user_id,
            restaurant_id=restaurant_id,
            items=json.dumps(valid_items),
            total_amount=total,
            delivery_location=delivery_location,
            special_instructions=special_instructions,
            estimated_delivery=estimated_delivery
        )
        
        db.session.add(order)
        db.session.commit()
        
        return {
            'order_id': order.id,
            'total': total,
            'estimated_delivery': estimated_delivery.isoformat(),
            'items': valid_items
        }

# Initialize systems
outlook_manager = EnhancedOutlookManager(AZURE_CLIENT_ID, SCOPES)
complaint_processor = ComplaintProcessor(GROQ_API_KEY)
campus_navigator = None
food_system = None
agentic_helper = AgenticHelper(GROQ_AGENT_API_KEY, mistral_client=mistral_ocr_client)


def get_campus_navigator() -> CampusNavigator:
    """Lazily initialize and return the CampusNavigator.

    This avoids using the database outside an application context.
    """
    global campus_navigator
    if campus_navigator is None:
        campus_navigator = CampusNavigator()
    return campus_navigator


def get_food_system() -> FoodOrderingSystem:
    """Lazily initialize and return the FoodOrderingSystem."""
    global food_system
    if food_system is None:
        food_system = FoodOrderingSystem()
    return food_system


def geocode_giki_location(name: str) -> tuple[Optional[float], Optional[float]]:
    """Geocode a location constrained to GIKI using known coordinates or Nominatim.
    
    First checks against known GIKI location coordinates for accuracy.
    Falls back to Nominatim with GIKI suffix if not found.
    """
    # Known accurate coordinates for GIKI locations
    known_locations = {
        "academic block giki": (33.7841, 72.3743),
        "cs department giki": (33.7840, 72.3742),
        "electrical engineering department giki": (33.7842, 72.3744),
        "central library giki": (33.7842, 72.3744),
        "student center giki": (33.7843, 72.3745),
        "main mess giki": (33.7843, 72.3745),
        "lecture hall a giki": (33.7841, 72.3743),
        "lecture hall b giki": (33.7841, 72.3743),
        "computer lab 1 giki": (33.7840, 72.3742),
        "computer lab 2 giki": (33.7840, 72.3742),
        "electronics lab giki": (33.7842, 72.3744),
        "digital systems lab giki": (33.7842, 72.3744),
        "giki main campus": (33.784, 72.374),
        "ghulam ishaq khan institute": (33.784, 72.374),
    }
    
    # Normalize the query for lookup
    normalized_query = name.lower().strip()
    
    # Check if we have known coordinates
    if normalized_query in known_locations:
        return known_locations[normalized_query]
    
    # Try partial matching for building names
    for known_name, coords in known_locations.items():
        if known_name.split()[0] in normalized_query or normalized_query.split()[0] in known_name:
            return coords
    
    # Fallback to Nominatim
    suffix = " in ghulam ishaq khan institute , topo district swabi , kpk"
    full_query = f"{name}{suffix}"
    try:
        resp = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={
                "q": full_query,
                "format": "json",
                "limit": 1,
            },
            headers={"User-Agent": "giki-student-services-app/1.0 (navigation)"},
            timeout=5,
        )
        if resp.status_code != 200:
            return None, None
        data = resp.json() or []
        if not data:
            return None, None
        return float(data[0]["lat"]), float(data[0]["lon"])
    except Exception as e:
        print(f"Geocode failed for {full_query}: {e}")
        return None, None

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login():
    """Initiate Outlook login"""
    try:
        flow = outlook_manager.authenticate()
        session['device_flow'] = flow
        return render_template('login.html', flow=flow)
    except Exception as e:
        flash(f'Login error: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/auth/callback')
def auth_callback():
    """Handle authentication callback"""
    global outlook_manager
    flow = session.get('device_flow')
    if not flow:
        flash('Authentication session expired', 'error')
        return redirect(url_for('index'))
    
    # Create fresh outlook manager for authentication
    outlook_manager = EnhancedOutlookManager(AZURE_CLIENT_ID, SCOPES)
    outlook_manager.authenticate()  # Initialize the MSAL app
    
    if outlook_manager.acquire_token_by_device_flow(flow):
        user_info = outlook_manager.get_user_info()
        if user_info:
            # Create or update user
            user = User.query.filter_by(email=user_info['mail'] or user_info['userPrincipalName']).first()
            if not user:
                # Extract roll number from email (assuming format: u2022074@giki.edu.pk)
                email = user_info['mail'] or user_info['userPrincipalName']
                roll_number = email.split('@')[0] if '@giki.edu.pk' in email else email
                
                user = User(
                    email=email,
                    name=user_info['displayName'],
                    roll_number=roll_number,
                    outlook_token=outlook_manager.access_token
                )
                db.session.add(user)
            else:
                user.outlook_token = outlook_manager.access_token
            
            db.session.commit()
            session['user_id'] = user.id
            session['user_email'] = user.email
            flash(f'Welcome, {user.name}!' , 'success')
            return redirect(url_for('dashboard'))
    
    flash('Authentication failed', 'error')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    """Main dashboard"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    return render_template('dashboard.html', user=user)

@app.route('/api/complaint', methods=['POST'])
def create_complaint():
    """Create new complaint"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    description = data.get('description', '')
    
    if not description:
        return jsonify({'error': 'Description is required'}), 400
    
    # Process complaint with AI
    categorization = complaint_processor.categorize_complaint(description)
    relevant_contacts = complaint_processor.find_relevant_contacts(categorization['category'])
    
    # Create complaint
    complaint = Complaint(
        user_id=session['user_id'],
        category=categorization['category'],
        subcategory=categorization.get('subcategory'),
        description=description,
        urgency=categorization['urgency']
    )
    
    db.session.add(complaint)
    db.session.commit()
    
    return jsonify({
        'complaint_id': complaint.id,
        'category': categorization['category'],
        'urgency': categorization['urgency'],
        'contacts': relevant_contacts
    })

@app.route('/api/search_location')
def search_location():
    """Search for campus locations"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    query = request.args.get('q', '')
    navigator = get_campus_navigator()
    results = navigator.search_location(query)
    
    return jsonify({'results': results})

@app.route('/api/directions')
def get_directions():
    """Get directions between locations"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    from_lat = float(request.args.get('from_lat'))
    from_lng = float(request.args.get('from_lng'))
    to_lat = float(request.args.get('to_lat'))
    to_lng = float(request.args.get('to_lng'))
    
    navigator = get_campus_navigator()
    directions = navigator.get_directions(from_lat, from_lng, to_lat, to_lng)
    
    return jsonify(directions)

@app.route('/api/restaurant/<int:restaurant_id>/menu')
def get_menu(restaurant_id):
    """Get restaurant menu"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    system = get_food_system()
    menu = system.get_menu(restaurant_id)
    return jsonify({'menu': menu})

@app.route('/api/order', methods=['POST'])
def create_order():
    """Create food order"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    system = get_food_system()
    result = system.create_order(
        user_id=session['user_id'],
        restaurant_id=data['restaurant_id'],
        items=data['items'],
        delivery_location=data.get('delivery_location'),
        special_instructions=data.get('special_instructions')
    )
    
    if 'error' in result:
        return jsonify(result), 400
    
    return jsonify(result)

@app.route('/api/outlook/status')
def outlook_status():
    """Check Outlook authentication status"""
    if 'user_id' not in session:
        return jsonify({'authenticated': False, 'error': 'Not logged in'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.outlook_token:
        return jsonify({'authenticated': False, 'error': 'Not connected to Outlook'})
    
    # Test the token by making a simple API call
    outlook_manager.access_token = user.outlook_token
    user_info = outlook_manager.get_user_info()
    
    if user_info:
        return jsonify({
            'authenticated': True, 
            'email': user_info.get('mail') or user_info.get('userPrincipalName'),
            'name': user_info.get('displayName')
        })
    else:
        return jsonify({'authenticated': False, 'error': 'Token expired or invalid'}), 401

@app.route('/api/outlook/emails')
def get_outlook_emails():
    """Get Outlook emails"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.outlook_token:
        return jsonify({'error': 'Not connected to Outlook. Please login first.'}), 400
    
    # Set token and fetch emails
    outlook_manager.access_token = user.outlook_token
    emails = outlook_manager.get_emails(max_emails=50, days_back=7)
    
    if not emails:
        # Check if there was an authentication issue
        if not outlook_manager.access_token:
            return jsonify({'error': 'Authentication failed. Please login again.'}), 401
        else:
            return jsonify({'emails': [], 'message': 'No recent emails found in the last 7 days.'})
    
    return jsonify({'emails': emails})

@app.route('/api/outlook/send', methods=['POST'])
def send_outlook_email():
    """Send email via Outlook"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    user = User.query.get(session['user_id'])
    
    if not user.outlook_token:
        return jsonify({'error': 'Not connected to Outlook'}), 400
    
    outlook_manager.access_token = user.outlook_token
    success = outlook_manager.send_email(
        to_recipients=data['to'],
        subject=data['subject'],
        body=data['body'],
        cc_recipients=data.get('cc', [])
    )
    
    if success:
        return jsonify({'success': True})
    else:
        return jsonify({'error': 'Failed to send email'}), 500


@app.route('/api/agent/plan', methods=['POST'])
def agent_plan():
    """Agentic helper endpoint.

    Expects JSON: {"goal": "...", "context": {...optional...}}

    It returns a JSON object with a high-level plan and a list of actions.
    The caller is responsible for asking the user for approval and then
    explicitly calling the relevant backend APIs; this endpoint NEVER
    performs side effects on its own.
    """
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    goal = (data.get('goal') or '').strip()
    if not goal:
        return jsonify({'error': 'goal is required'}), 400

    context = data.get('context') or {}
    plan = agentic_helper.plan_actions(goal, context=context)
    return jsonify(plan)


@app.route('/api/feedback', methods=['POST'])
def create_feedback():
    """Create text-based feedback between student/faculty/admin."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    message = (data.get('message') or '').strip()
    if not message:
        return jsonify({'error': 'Message is required'}), 400

    feedback = Feedback(
        from_user_id=session['user_id'],
        to_user_id=data.get('to_user_id'),
        from_role=data.get('from_role'),
        to_role=data.get('to_role'),
        channel=data.get('channel'),
        content=message,
        source='text',
    )
    db.session.add(feedback)
    db.session.commit()

    return jsonify({'success': True, 'feedback_id': feedback.id})


@app.route('/api/feedback', methods=['GET'])
def list_feedback():
    """List recent feedback items for the logged-in user (sent and received)."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    user_id = session['user_id']
    items = (
        Feedback.query
        .filter((Feedback.from_user_id == user_id) | (Feedback.to_user_id == user_id))
        .order_by(Feedback.created_at.desc())
        .limit(20)
        .all()
    )

    return jsonify({
        'feedback': [
            {
                'id': f.id,
                'from_user_id': f.from_user_id,
                'to_user_id': f.to_user_id,
                'from_role': f.from_role,
                'to_role': f.to_role,
                'channel': f.channel,
                'content': f.content,
                'source': f.source,
                'created_at': f.created_at.isoformat(),
            }
            for f in items
        ]
    })


@app.route('/api/feedback/ocr', methods=['POST'])
def feedback_ocr():
    """Accept an image upload, run Mistral OCR, and return extracted markdown text.

    Intended for handwritten or scanned feedback/complaints between
    students, faculty, and administrators.
    """
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    if mistral_ocr_client is None:
        return jsonify({'error': 'OCR service not configured. Missing MISTRAL_API_KEY.'}), 500

    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Empty filename'}), 400

    # Simple, safe temporary save
    upload_dir = os.path.join(os.getcwd(), 'uploads')
    os.makedirs(upload_dir, exist_ok=True)
    temp_path = os.path.join(upload_dir, f"ocr_{int(time.time())}_{file.filename}")
    file.save(temp_path)

    try:
        base64_image = encode_image(temp_path)

        ocr_response = mistral_ocr_client.ocr.process(
            model="mistral-ocr-latest",
            document={
                "type": "image_url",
                "image_url": f"data:image/jpeg;base64,{base64_image}",
            },
            include_image_base64=False,
        )

        # Extract markdown from first page (most common case)
        pages = getattr(ocr_response, 'pages', None) or ocr_response.get('pages', [])
        markdown = pages[0].markdown if pages else ""

        # Store as feedback linked to roles/channel if provided
        from_role = request.form.get('from_role')
        to_role = request.form.get('to_role')
        channel = request.form.get('channel')
        to_user_id = request.form.get('to_user_id')

        feedback = Feedback(
            from_user_id=session['user_id'],
            to_user_id=int(to_user_id) if to_user_id else None,
            from_role=from_role,
            to_role=to_role,
            channel=channel,
            content=markdown,
            source='ocr',
        )
        db.session.add(feedback)
        db.session.commit()

        return jsonify({
            'markdown': markdown,
            'feedback_id': feedback.id,
            'model': getattr(ocr_response, 'model', None) or ocr_response.get('model'),
        })
    except Exception as e:
        return jsonify({'error': f'OCR failed: {str(e)}'}), 500
    finally:
        try:
            os.remove(temp_path)
        except Exception:
            pass

# Initialize database
# @app.before_first_request
def init_db():
    """Initialize database with sample data"""
    db.create_all()
    
    # Add sample department contacts
    if not DepartmentContact.query.first():
        contacts = [
            DepartmentContact(
                name='Dr. Ahmed Khan',
                department='Academic Affairs',
                designation='Dean Academic Affairs',
                email='dean.academic@giki.edu.pk',
                phone='053-1234567',
                office_location='Admin Building, Room 101'
            ),
            DepartmentContact(
                name='Mr. Ali Hassan',
                department='Hostel Management',
                designation='Hostel Warden',
                email='warden.male@giki.edu.pk',
                phone='053-7654321',
                office_location='Hostel A, Ground Floor'
            ),
            DepartmentContact(
                name='Ms. Sarah Ahmed',
                department='IT Department',
                designation='Network Administrator',
                email='it.support@giki.edu.pk',
                phone='053-9876543',
                office_location='Computer Lab Building'
            ),
            DepartmentContact(
                name='Mr. Omar Farooq',
                department='Maintenance',
                designation='Chief Maintenance Officer',
                email='maintenance@giki.edu.pk',
                phone='053-1928374',
                office_location='Maintenance Block'
            )
        ]
        db.session.bulk_save_objects(contacts)
        db.session.commit()

    # Add campus locations around GIKI if none exist
    if not CampusLocation.query.first():
        # 1) Prefer importing from scraper output if available
        scraper_json = os.path.join(os.path.dirname(__file__), 'tools', 'scraped_campus_locations.json')
        if os.path.exists(scraper_json):
            try:
                with open(scraper_json, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                giki = data.get('giki', {})
                buildings = giki.get('buildings', {})
                for bkey, b in buildings.items():
                    # Base building location
                    base_lat = b.get('lat')
                    base_lon = b.get('lon')
                    # Add labs
                    for lab in b.get('labs', []):
                        lat = lab.get('lat') or base_lat
                        lon = lab.get('lon') or base_lon
                        if lat is None or lon is None:
                            continue
                        faculty = lab.get('faculty')
                        desc = f"Lab in {b.get('name') or bkey}"
                        if faculty:
                            desc += f" ({faculty})"
                        kw_list = ['lab', b.get('name', ''), lab.get('name', '')]
                        if faculty:
                            kw_list.append(faculty)
                        loc = CampusLocation(
                            name=lab.get('name', 'Lab'),
                            category='lab',
                            building=b.get('name') or bkey,
                            floor=None,
                            latitude=lat,
                            longitude=lon,
                            description=desc,
                            keywords=json.dumps(kw_list)
                        )
                        db.session.add(loc)
                    # Add classrooms
                    for room in b.get('classrooms', []):
                        lat = room.get('lat') or base_lat
                        lon = room.get('lon') or base_lon
                        if lat is None or lon is None:
                            continue
                        faculty = room.get('faculty')
                        desc = f"Classroom in {b.get('name') or bkey}"
                        if faculty:
                            desc += f" ({faculty})"
                        kw_list = ['classroom', 'lecture', b.get('name', ''), room.get('name', '')]
                        if faculty:
                            kw_list.append(faculty)
                        loc = CampusLocation(
                            name=room.get('name', 'Classroom'),
                            category='classroom',
                            building=b.get('name') or bkey,
                            floor=None,
                            latitude=lat,
                            longitude=lon,
                            description=desc,
                            keywords=json.dumps(kw_list)
                        )
                        db.session.add(loc)
                db.session.commit()
                print('Imported campus locations from scraped_campus_locations.json')
            except Exception as e:
                print(f'Failed to import scraped campus locations: {e}')

        # 2) Fallback: manual seed locations if scraper data not present or failed
        if not CampusLocation.query.first():
            # Seed using geocode_giki_location so everything is properly
            # constrained to GIKI instead of arbitrary placeholder coords.
            seed_defs = [
                {
                    'name': 'Lecture Hall 1 (ACB)',
                    'category': 'classroom',
                    'building': 'Academic Block (ACB)',
                    'floor': '1',
                    'desc': 'Main lecture hall in ACB used for core courses.',
                    'keywords': ['lecture', 'hall', 'acb', 'classroom', 'lh1'],
                    'geo_name': 'Academic Block GIKI',
                },
                {
                    'name': 'Lecture Hall 2 (ACB)',
                    'category': 'classroom',
                    'building': 'Academic Block (ACB)',
                    'floor': '1',
                    'desc': 'Second lecture hall in ACB.',
                    'keywords': ['lecture', 'hall', 'acb', 'classroom', 'lh2'],
                    'geo_name': 'Academic Block GIKI',
                },
                {
                    'name': 'Lecture Hall 3 (ACB)',
                    'category': 'classroom',
                    'building': 'Academic Block (ACB)',
                    'floor': '2',
                    'desc': 'Upper floor lecture hall in ACB.',
                    'keywords': ['lecture', 'hall', 'acb', 'classroom', 'lh3'],
                    'geo_name': 'Academic Block GIKI',
                },
                {
                    'name': 'Lecture Hall A',
                    'category': 'classroom',
                    'building': 'Academic Block',
                    'floor': 'Ground',
                    'desc': 'Large lecture hall for 200 students.',
                    'keywords': ['lecture', 'hall', 'classroom', 'a'],
                    'geo_name': 'Academic Block GIKI',
                },
                {
                    'name': 'Lecture Hall B',
                    'category': 'classroom',
                    'building': 'Academic Block',
                    'floor': 'Ground',
                    'desc': 'Medium-sized lecture hall.',
                    'keywords': ['lecture', 'hall', 'classroom', 'b'],
                    'geo_name': 'Academic Block GIKI',
                },
                {
                    'name': 'Software Engineering Lab',
                    'category': 'lab',
                    'building': 'CS Department',
                    'floor': 'Ground',
                    'desc': 'Primary lab for Software Engineering students.',
                    'keywords': ['software', 'engineering', 'lab', 'se', 'selab'],
                    'geo_name': 'CS Department GIKI',
                },
                {
                    'name': 'Computer Lab 1',
                    'category': 'lab',
                    'building': 'CS Department',
                    'floor': '1',
                    'desc': 'Main undergraduate computer laboratory.',
                    'keywords': ['computer', 'lab', 'programming', 'cs', 'lab1'],
                    'geo_name': 'CS Department GIKI',
                },
                {
                    'name': 'Computer Lab 2',
                    'category': 'lab',
                    'building': 'CS Department',
                    'floor': '1',
                    'desc': 'Advanced programming and AI lab.',
                    'keywords': ['computer', 'lab', 'ai', 'cs', 'lab2'],
                    'geo_name': 'CS Department GIKI',
                },
                {
                    'name': 'Electronics Lab',
                    'category': 'lab',
                    'building': 'EE Department',
                    'floor': 'Ground',
                    'desc': 'Electronics and circuits laboratory.',
                    'keywords': ['electronics', 'lab', 'ee', 'circuits'],
                    'geo_name': 'Electrical Engineering Department GIKI',
                },
                {
                    'name': 'Digital Systems Lab',
                    'category': 'lab',
                    'building': 'EE Department',
                    'floor': '1',
                    'desc': 'Digital logic and embedded systems lab.',
                    'keywords': ['digital', 'systems', 'lab', 'ee'],
                    'geo_name': 'Electrical Engineering Department GIKI',
                },
                {
                    'name': 'Central Library',
                    'category': 'library',
                    'building': 'Library Building',
                    'floor': 'Multiple',
                    'desc': 'Main campus library and study area.',
                    'keywords': ['library', 'study', 'books', 'reading'],
                    'geo_name': 'Central Library GIKI',
                },
                {
                    'name': 'Student Mess Hall',
                    'category': 'mess',
                    'building': 'Student Center',
                    'floor': 'Ground',
                    'desc': 'Main student dining hall.',
                    'keywords': ['mess', 'food', 'dining', 'cafeteria'],
                    'geo_name': 'Student Center GIKI',
                },
            ]

            for sd in seed_defs:
                lat, lon = geocode_giki_location(sd['geo_name'])
                if lat is None or lon is None:
                    continue
                location = CampusLocation(
                    name=sd['name'],
                    category=sd['category'],
                    building=sd['building'],
                    floor=sd['floor'],
                    latitude=lat,
                    longitude=lon,
                    description=sd['desc'],
                    keywords=json.dumps(sd['keywords']),
                )
                db.session.add(location)
    
    # Add sample restaurants
    if not Restaurant.query.first():
        restaurants = [
            Restaurant(
                name='Main Mess',
                category='mess',
                location='Student Center',
                phone='053-1111111'
            ),
            Restaurant(
                name='GIKI Cafe',
                category='cafe',
                location='Academic Block',
                phone='053-2222222'
            ),
            Restaurant(
                name='TUC Food Court',
                category='tuc',
                location='Student Union Building',
                phone='053-3333333'
            )
        ]
        
        for restaurant in restaurants:
            db.session.add(restaurant)
            db.session.flush()  # Get ID without committing
            
            # Add sample menu items
            menu_items = [
                MenuItem(
                    restaurant_id=restaurant.id,
                    name='Biryani',
                    description='Traditional chicken biryani',
                    price=150.0,
                    category='main',
                    preparation_time=15
                ),
                MenuItem(
                    restaurant_id=restaurant.id,
                    name='Karhi',
                    description='Traditional karhi with rice',
                    price=120.0,
                    category='main',
                    preparation_time=10
                ),
                MenuItem(
                    restaurant_id=restaurant.id,
                    name='Tea',
                    description='Hot chai tea',
                    price=30.0,
                    category='beverage',
                    preparation_time=5
                )
            ]
            
            for item in menu_items:
                db.session.add(item)
    
    db.session.commit()
    print("Database initialized with sample data!")

# Additional API Endpoints
@app.route('/api/dashboard/stats')
def dashboard_stats():
    """Get dashboard statistics"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.get(session['user_id'])
    
    # Get email count
    email_count = 0
    if user.outlook_token:
        outlook_manager.access_token = user.outlook_token
        try:
            emails = outlook_manager.get_emails(max_emails=50, days_back=7)
            email_count = len([e for e in emails if not e.get('isRead', True)])
        except:
            pass
    
    # Get complaint stats
    active_complaints = Complaint.query.filter_by(user_id=user.id, status='pending').count()
    
    # Get order stats
    pending_orders = Order.query.filter_by(user_id=user.id, status='pending').count()
    
    return jsonify({
        'emails': email_count,
        'complaints': active_complaints,
        'orders': pending_orders
    })

@app.route('/api/notifications')
def get_notifications():
    """Get user notifications"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    notifications = [
        {'id': 1, 'message': 'Your complaint has been received', 'type': 'info', 'time': '2024-01-15 10:30'},
        {'id': 2, 'message': 'Order delivered successfully', 'type': 'success', 'time': '2024-01-15 12:15'}
    ]
    
    return jsonify({'notifications': notifications})

@app.route('/health')
def health_check():
    return jsonify({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()})

# Session validation decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Apply to protected routes

@app.route('/complaints')
@login_required
def complaints():
    """Complaint management page"""
    user = User.query.get(session['user_id'])
    user_complaints = Complaint.query.filter_by(user_id=user.id).order_by(Complaint.created_at.desc()).all()
    return render_template('complaints.html', user=user, complaints=user_complaints)

@app.route('/navigation')
@login_required
def navigation():
    """Campus navigation page"""
    user = User.query.get(session['user_id'])
    return render_template('navigation.html', user=user)

@app.route('/food')
@login_required
def food():
    """Food ordering page"""
    user = User.query.get(session['user_id'])
    restaurants = Restaurant.query.all()
    return render_template('food.html', user=user, restaurants=restaurants)

# Optimized authentication endpoint
@app.route('/api/auth/poll')
def poll_auth():
    """Poll for authentication completion"""
    global outlook_manager
    flow = session.get('device_flow')
    
    if not flow:
        return jsonify({'error': 'Session expired'})
    
    # Check if authentication is complete
    try:
        outlook_manager = EnhancedOutlookManager(AZURE_CLIENT_ID, SCOPES)
        if outlook_manager.acquire_token_by_device_flow(flow):
            user_info = outlook_manager.get_user_info()
            if user_info:
                # Create or update user
                user = User.query.filter_by(email=user_info['mail'] or user_info['userPrincipalName']).first()
                if not user:
                    email = user_info['mail'] or user_info['userPrincipalName']
                    roll_number = email.split('@')[0] if '@giki.edu.pk' in email else email
                    
                    user = User(
                        email=email,
                        name=user_info['displayName'],
                        roll_number=roll_number,
                        outlook_token=outlook_manager.access_token
                    )
                    db.session.add(user)
                else:
                    user.outlook_token = outlook_manager.access_token
                
                db.session.commit()
                session['user_id'] = user.id
                session['user_email'] = user.email
                
                return jsonify({
                    'success': True,
                    'user': {
                        'name': user.name,
                        'email': user.email,
                        'roll_number': user.roll_number
                    }
                })
        
        return jsonify({'success': False, 'message': 'Authentication pending'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# Global authentication state
_auth_manager = None
_auth_flow = None

@app.route('/api/auth/fast-poll')
def fast_poll_auth():
    """Fast polling with persistent manager"""
    global _auth_manager, _auth_flow
    
    flow = session.get('device_flow')
    if not flow:
        return jsonify({'error': 'Session expired'})
    
    try:
        # Reuse manager if available
        if _auth_manager is None or _auth_flow != flow:
            _auth_manager = EnhancedOutlookManager(AZURE_CLIENT_ID, SCOPES)
            _auth_flow = flow
        
        # Quick check
        if _auth_manager.acquire_token_by_device_flow(flow):
            user_info = _auth_manager.get_user_info()
            if user_info:
                # Quick user creation/update
                email = user_info['mail'] or user_info['userPrincipalName']
                user = User.query.filter_by(email=email).first()
                
                if not user:
                    roll_number = email.split('@')[0] if '@giki.edu.pk' in email else email
                    user = User(
                        email=email,
                        name=user_info['displayName'],
                        roll_number=roll_number,
                        outlook_token=_auth_manager.access_token
                    )
                    db.session.add(user)
                else:
                    user.outlook_token = _auth_manager.access_token
                
                db.session.commit()
                session['user_id'] = user.id
                session['user_email'] = user.email
                
                # Clear global state
                _auth_manager = None
                _auth_flow = None
                
                return jsonify({
                    'success': True,
                    'user': {'name': user.name, 'email': user.email}
                })
        
        return jsonify({'success': False})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# Simplified direct authentication
@app.route('/api/auth/direct')
def direct_auth():
    """Direct authentication without device flow for testing"""
    # For demo purposes, create a test user
    email = "test@giki.edu.pk"
    user = User.query.filter_by(email=email).first()
    
    if not user:
        user = User(
            email=email,
            name="Test Student",
            roll_number="u2022074",
            outlook_token="demo_token"
        )
        db.session.add(user)
        db.session.commit()
    
    session['user_id'] = user.id
    session['user_email'] = user.email
    
    return jsonify({
        'success': True,
        'user': {
            'name': user.name,
            'email': user.email,
            'roll_number': user.roll_number
        }
    })

# Quick login endpoint
@app.route('/quick-login')
def quick_login():
    """Quick login for testing"""
    try:
        # Create or get test user directly
        email = "test@giki.edu.pk"
        roll_number = "u2022074"
        user = User.query.filter((User.email == email) | (User.roll_number == roll_number)).first()
        
        if not user:
            user = User(
                email=email,
                name="Test Student",
                roll_number=roll_number,
                outlook_token="demo_token"
            )
            db.session.add(user)
            db.session.commit()

        
        # Set session directly
        session['user_id'] = user.id
        session['user_email'] = user.email
        session['user_name'] = user.name
        
        return redirect(url_for('dashboard'))
    except Exception as e:
        print(f"Quick login error: {e}")
        return redirect(url_for('login'))


# ==================== NEW: RAG SYSTEM ENDPOINTS ====================

@app.route('/api/rag/index', methods=['POST'])
def index_emails_rag():
    """Index current month's emails into RAG system."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.outlook_token:
        return jsonify({'error': 'Outlook not connected'}), 400
    
    outlook_manager.access_token = user.outlook_token
    emails = outlook_manager.get_emails(max_emails=100, days_back=30)
    
    if not emails:
        return jsonify({'error': 'No emails found'}), 404
    
    num_indexed = rag_system.index_current_month_emails(emails)
    
    return jsonify({
        'success': True,
        'emails_processed': len(emails),
        'chunks_indexed': num_indexed
    })


@app.route('/api/rag/search', methods=['GET'])
def search_emails_rag():
    """Semantic search over indexed emails."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    query = request.args.get('q', '')
    if not query:
        return jsonify({'error': 'Query required'}), 400
    
    results = rag_system.semantic_search(query, k=5)
    return jsonify({'results': results, 'query': query})


@app.route('/api/rag/query', methods=['POST'])
def query_with_llm_rag():
    """Answer question using RAG + LLM."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    query = data.get('query', '')
    
    if not query:
        return jsonify({'error': 'Query required'}), 400
    
    result = rag_system.query_with_llm(query, k=3)
    return jsonify(result)


# ==================== NEW: EVENT EXTRACTION ENDPOINTS ====================

@app.route('/api/events/extract', methods=['POST'])
def extract_events():
    """Extract events from Outlook emails."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.outlook_token:
        return jsonify({'error': 'Outlook not connected'}), 400
    
    outlook_manager.access_token = user.outlook_token
    emails = outlook_manager.get_emails(max_emails=50, days_back=60)
    
    if not emails:
        return jsonify({'error': 'No emails found'}), 404
    
    events = event_extractor.extract_events_from_emails(emails, use_llm=True)
    
    for event_data in events:
        event = Event(
            title=event_data.get('title', 'Untitled Event'),
            event_type=event_data.get('type', 'other'),
            description=event_data.get('description'),
            date=event_data.get('date'),
            time=event_data.get('time'),
            location=event_data.get('location'),
            organizer=event_data.get('organizer'),
            source_email_id=event_data.get('source_email_id'),
            source_email_subject=event_data.get('source_email_subject'),
            registration_required=event_data.get('registration_required', False),
            extraction_method=event_data.get('extraction_method', 'llm'),
            extracted_at=event_data.get('extracted_at')
        )
        db.session.add(event)
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'events_extracted': len(events),
        'events': events
    })


@app.route('/api/events', methods=['GET'])
def get_events():
    """Get all extracted events."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    event_type = request.args.get('type')
    days_ahead = int(request.args.get('days_ahead', 30))
    
    query = Event.query
    
    if event_type:
        query = query.filter_by(event_type=event_type)
    
    events = query.order_by(Event.created_at.desc()).all()
    
    event_dicts = [
        {
            'id': e.id,
            'title': e.title,
            'type': e.event_type,
            'description': e.description,
            'date': e.date,
            'time': e.time,
            'location': e.location,
            'organizer': e.organizer,
            'registration_required': e.registration_required
        }
        for e in events
    ]
    
    upcoming = event_extractor.filter_upcoming_events(event_dicts, days_ahead)
    
    return jsonify({'events': upcoming})


# ==================== NEW: CHAT SYSTEM ENDPOINTS ====================

@app.route('/api/chat/channels', methods=['GET'])
def get_chat_channels():
    """Get all chat channels."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if not chat_system:
        return jsonify({'error': 'Chat system not initialized'}), 500
    
    channels = chat_system.get_channels()
    return jsonify({'channels': channels})


@app.route('/api/chat/messages/<int:channel_id>', methods=['GET'])
def get_channel_messages(channel_id):
    """Get messages from a channel."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if not chat_system:
        return jsonify({'error': 'Chat system not initialized'}), 500
    
    limit = int(request.args.get('limit', 50))
    messages = chat_system.get_channel_messages(channel_id, limit)
    
    return jsonify({'messages': messages})


@app.route('/api/chat/active_users', methods=['GET'])
def get_active_chat_users():
    """Get currently active users."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if not chat_system:
        return jsonify({'error': 'Chat system not initialized'}), 500
    
    users = chat_system.get_active_users()
    return jsonify({'active_users': users})


# ==================== NEW: PAGE ROUTES ====================

@app.route('/events')
@login_required
def events_page():
    """Events and news page."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    return render_template('events.html', user=user)


@app.route('/chat')
def chat_page():
    """Real-time chat page."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    session['user_name'] = user.name
    return render_template('chat.html', user=user)


if __name__ == '__main__':
    # Initialize database and chat system with app context
    with app.app_context():
        db.create_all()
        print("Database initialized!")
        
        # Initialize chat system with default channels (must be in app context)
        chat_system_instance = ChatSystem(socketio, db)
        # Only initialize default channels if none exist
        try:
            from chat_system import ChatChannel
            if ChatChannel.query.count() == 0:
                initialize_default_channels(chat_system_instance)
                print("✅ Chat channels created")
            else:
                print("✅ Chat channels already exist")
        except Exception as e:
            print(f"⚠️  Chat system initialization warning: {e}")
        
        # Update the global reference
        globals()['chat_system'] = chat_system_instance
        print("✅ Chat system initialized")
    # Initialize database
    with app.app_context():
        init_db()
        
    # Start the app with SocketIO support on port 9000
    print("Starting Flask app with SocketIO on port 9000...")
    print("=" * 60)
    print("🚀 Server ready at http://localhost:9000")
    print("=" * 60)
    socketio.run(app, debug=True, host='0.0.0.0', port=9000)



