# Custom REST API Setup Guide
## GIKI Student Services Platform (Without Azure)

### Overview
Instead of using Azure/Microsoft services, we'll build our own:
- Authentication system
- Email service  
- User directory
- Notification system
- File storage

### Step 1: Enhanced Database Models

We'll extend your existing models to support full functionality:

```python
# Enhanced User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    roll_number = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(255))  # Add password
    role = db.Column(db.String(20), default='student')  # student, faculty, admin
    department = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    hostel = db.Column(db.String(50))
    room_number = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    profile_picture = db.Column(db.String(255))

# Custom Email System
class Email(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    from_user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    to_user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    subject = db.Column(db.String(255), nullable=False)
    body = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    is_sent = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    sent_at = db.Column(db.DateTime)
    
    from_user = db.relationship('User', foreign_keys=[from_user_id], backref='sent_emails')
    to_user = db.relationship('User', foreign_keys=[to_user_id], backref='received_emails')

# Notification System
class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    title = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(20))  # info, warning, success, error
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='notifications')

# File Storage System
class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    file_size = db.Column(db.Integer)
    file_type = db.Column(db.String(50))
    category = db.Column(db.String(50))  # assignment, notes, admin, etc.
    is_public = db.Column(db.Boolean, default=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='documents')
```

### Step 2: Custom Authentication System

```python
# Authentication utilities
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Custom login system
@app.route('/auth/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        data = request.get_json()
        
        # Check if user exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already registered'}), 400
        
        if User.query.filter_by(roll_number=data['roll_number']).first():
            return jsonify({'error': 'Roll number already registered'}), 400
        
        # Create new user
        user = User(
            email=data['email'],
            name=data['name'],
            roll_number=data['roll_number'],
            password_hash=generate_password_hash(data['password']),
            role=data.get('role', 'student'),
            department=data.get('department'),
            phone=data.get('phone'),
            hostel=data.get('hostel'),
            room_number=data.get('room_number')
        )
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify({'message': 'Registration successful', 'user_id': user.id})
    
    return render_template('register.html')

@app.route('/auth/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.get_json()
        
        user = User.query.filter_by(email=data['email']).first()
        
        if user and check_password_hash(user.password_hash, data['password']):
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            return jsonify({
                'message': 'Login successful',
                'user': {
                    'id': user.id,
                    'name': user.name,
                    'email': user.email,
                    'role': user.role
                }
            })
        
        return jsonify({'error': 'Invalid credentials'}), 401
    
    return render_template('login.html')

@app.route('/auth/logout')
@login_required
def logout():
    logout_user()
    return jsonify({'message': 'Logged out successfully'})
```

### Step 3: Custom Email Service

```python
# Email sending without Outlook
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

class CustomEmailService:
    def __init__(self):
        # Configure with your email provider
        self.smtp_server = "smtp.gmail.com"  # Or your institutional email
        self.smtp_port = 587
        self.smtp_username = "your-email@institution.edu"
        self.smtp_password = "your-app-password"
    
    def send_email(self, to_email, subject, body, from_email=None):
        try:
            msg = MIMEMultipart()
            msg['From'] = from_email or self.smtp_username
            msg['To'] = to_email
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'html'))
            
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            server.login(self.smtp_username, self.smtp_password)
            text = msg.as_string()
            server.sendmail(self.smtp_username, to_email, text)
            server.quit()
            
            return True
        except Exception as e:
            print(f"Email sending failed: {e}")
            return False

# Initialize email service
email_service = CustomEmailService()

@app.route('/api/emails/send', methods=['POST'])
@login_required
def send_email():
    data = request.get_json()
    
    # Create email record
    email = Email(
        from_user_id=current_user.id,
        to_user_id=data['to_user_id'],
        subject=data['subject'],
        body=data['body']
    )
    db.session.add(email)
    
    # Get recipient
    to_user = User.query.get(data['to_user_id'])
    
    # Send actual email
    if email_service.send_email(to_user.email, data['subject'], data['body']):
        email.is_sent = True
        email.sent_at = datetime.utcnow()
        
        # Create notification
        notification = Notification(
            user_id=to_user.id,
            title=f"New email from {current_user.name}",
            message=data['subject'],
            type='info'
        )
        db.session.add(notification)
    
    db.session.commit()
    return jsonify({'message': 'Email sent successfully'})
```

### Step 4: User Directory API

```python
@app.route('/api/users', methods=['GET'])
@login_required
def get_users():
    # Filter based on user role
    if current_user.role == 'admin':
        users = User.query.all()
    elif current_user.role == 'faculty':
        # Faculty can see students and other faculty
        users = User.query.filter(User.role.in_(['student', 'faculty'])).all()
    else:
        # Students can only see faculty and admin
        users = User.query.filter(User.role.in_(['faculty', 'admin'])).all()
    
    return jsonify({
        'users': [{
            'id': user.id,
            'name': user.name,
            'email': user.email,
            'role': user.role,
            'department': user.department,
            'phone': user.phone if current_user.role in ['admin', 'faculty'] else None
        } for user in users]
    })

@app.route('/api/users/search')
@login_required
def search_users():
    query = request.args.get('q', '')
    
    users = User.query.filter(
        User.name.contains(query) |
        User.email.contains(query) |
        User.roll_number.contains(query)
    ).all()
    
    return jsonify({
        'users': [{
            'id': user.id,
            'name': user.name,
            'email': user.email,
            'role': user.role,
            'department': user.department
        } for user in users]
    })
```

### Step 5: File Upload System

```python
import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'ppt', 'pptx'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/api/upload', methods=['POST'])
@login_required
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    category = request.form.get('category', 'general')
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # Add timestamp to avoid conflicts
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{timestamp}_{filename}"
        
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        # Create document record
        document = Document(
            user_id=current_user.id,
            filename=filename,
            original_filename=file.filename,
            file_path=file_path,
            file_size=os.path.getsize(file_path),
            file_type=file.filename.rsplit('.', 1)[1].lower(),
            category=category
        )
        
        db.session.add(document)
        db.session.commit()
        
        return jsonify({
            'message': 'File uploaded successfully',
            'document_id': document.id
        })
    
    return jsonify({'error': 'Invalid file type'}), 400
```

### Step 6: Enhanced Dashboard APIs

```python
@app.route('/api/dashboard/stats')
@login_required
def dashboard_stats():
    # Get user-specific stats
    unread_emails = Email.query.filter_by(
        to_user_id=current_user.id, 
        is_read=False
    ).count()
    
    active_complaints = Complaint.query.filter_by(
        user_id=current_user.id, 
        status='pending'
    ).count()
    
    pending_orders = Order.query.filter_by(
        user_id=current_user.id, 
        status='pending'
    ).count()
    
    unread_notifications = Notification.query.filter_by(
        user_id=current_user.id,
        is_read=False
    ).count()
    
    return jsonify({
        'emails': unread_emails,
        'complaints': active_complaints,
        'orders': pending_orders,
        'notifications': unread_notifications
    })

@app.route('/api/emails')
@login_required
def get_emails():
    emails = Email.query.filter_by(to_user_id=current_user.id).order_by(
        Email.created_at.desc()
    ).limit(50).all()
    
    return jsonify({
        'emails': [{
            'id': email.id,
            'from': email.from_user.name,
            'from_email': email.from_user.email,
            'subject': email.subject,
            'body': email.body,
            'is_read': email.is_read,
            'created_at': email.created_at.isoformat()
        } for email in emails]
    })
```

### Step 7: Installation Requirements

Add these to your `requirements.txt`:
```
flask-login==3.1.0
werkzeug==2.3.7
secure-smtplib==0.1.1
```

### Step 8: Frontend Updates

Update your JavaScript to work with the new API endpoints:
```javascript
// Update API calls in main.js
function updateDashboardStats() {
    fetch('/api/dashboard/stats', {
        headers: {
            'Authorization': `Bearer ${getAuthToken()}`
        }
    })
    .then(response => response.json())
    .then(data => {
        // Update dashboard with real data
    });
}
```

## Benefits of Custom API:

1. **Full Control** - No dependency on external services
2. **No Permissions Issues** - You own everything
3. **Customizable** - Add any features you want
4. **Offline Development** - Works without internet
5. **Better Performance** - No external API calls
6. **Data Privacy** - All data stays in your system

## Next Steps:

1. **Update your database models** (I can help migrate existing data)
2. **Add the new authentication system**
3. **Configure email service** (Gmail or institutional email)
4. **Test the new APIs**
5. **Update frontend to use new endpoints**

Would you like me to start implementing these changes? I can begin with the database models and authentication system.
