#!/usr/bin/env python3
"""
RAG (Retrieval-Augmented Generation) System for GIKI Student Services Platform
"""

import os
import json
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
from pathlib import Path

# Fix for protobuf registration conflict and framework detection
os.environ["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"] = "python"
os.environ["USE_TORCH"] = "1"

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.documents import Document
from langchain_groq import ChatGroq


class EmailRAGSystem:
    """RAG system for intelligent email processing and retrieval."""
    
    def __init__(self, groq_api_key: Optional[str] = None, persist_directory: str = "./chroma_db"):
        """Initialize the RAG system."""
        self.groq_api_key = groq_api_key
        self.persist_directory = persist_directory
        
        # Initialize embeddings model locally (using Torch)
        print("Initializing local embeddings model...")
        try:
            self.embeddings = HuggingFaceEmbeddings(
                model_name="sentence-transformers/all-MiniLM-L6-v2",
                model_kwargs={'device': 'cpu'}
            )
        except Exception as e:
            print(f"⚠️ Failed to initialize embeddings model: {e}")
            self.embeddings = None
        
        # Initialize or load vector store
        self.vectorstore = self._initialize_vectorstore()
        
        # Initialize LLM (Groq) if API key provided
        self.llm = None
        if groq_api_key:
            try:
                self.llm = ChatGroq(
                    groq_api_key=groq_api_key,
                    model_name="llama-3.1-70b-versatile",
                    temperature=0.3
                )
            except Exception as e:
                print(f"Failed to initialize Groq LLM: {e}")
        
        # Initialize text splitter for chunking
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""]
        )
    
    def _initialize_vectorstore(self) -> Optional[Chroma]:
        """Initialize or load the ChromaDB vector store."""
        if not self.embeddings:
            return None
            
        try:
            # Try to load existing vectorstore
            vectorstore = Chroma(
                persist_directory=self.persist_directory,
                embedding_function=self.embeddings,
                collection_name="giki_emails"
            )
            print(f"Loaded existing vector store from {self.persist_directory}")
            return vectorstore
        except Exception as e:
            print(f"Creating new vector store: {e}")
            try:
                # Create new vectorstore
                vectorstore = Chroma(
                    persist_directory=self.persist_directory,
                    embedding_function=self.embeddings,
                    collection_name="giki_emails"
                )
                return vectorstore
            except Exception as e2:
                print(f"Failed to create vector store: {e2}")
                return None
    
    def chunk_email(self, email: Dict[str, Any]) -> List[Document]:
        """Chunk an email into smaller documents for embedding."""
        subject = email.get('subject', 'No Subject')
        body = email.get('body', {}).get('content', '') or email.get('bodyPreview', '')
        sender = email.get('from', {}).get('emailAddress', {}).get('address', 'Unknown')
        received_date = email.get('receivedDateTime', '')
        email_id = email.get('id', '')
        
        full_text = f"Subject: {subject}\n\nFrom: {sender}\n\nDate: {received_date}\n\n{body}"
        chunks = self.text_splitter.split_text(full_text)
        
        documents = []
        for i, chunk in enumerate(chunks):
            doc = Document(
                page_content=chunk,
                metadata={
                    'email_id': email_id,
                    'subject': subject,
                    'sender': sender,
                    'received_date': received_date,
                    'chunk_index': i,
                    'total_chunks': len(chunks),
                    'source': 'outlook_email'
                }
            )
            documents.append(doc)
        return documents
    
    def index_emails(self, emails: List[Dict[str, Any]]) -> int:
        """Index a list of emails into the vector store."""
        if not self.vectorstore:
            print("⚠️ Vectorstore not initialized, skipping indexing.")
            return 0
        all_documents = []
        for email in emails:
            try:
                chunks = self.chunk_email(email)
                all_documents.extend(chunks)
            except Exception as e:
                print(f"Error chunking email {email.get('id', 'unknown')}: {e}")
                continue
        if all_documents:
            try:
                self.vectorstore.add_documents(all_documents)
                print(f"Indexed {len(all_documents)} document chunks from {len(emails)} emails")
                return len(all_documents)
            except Exception as e:
                print(f"Error adding documents to vectorstore: {e}")
                return 0
        return 0
    
    def semantic_search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """Perform semantic search over indexed emails."""
        if not self.vectorstore:
            return []
        try:
            results = self.vectorstore.similarity_search_with_score(query, k=k)
            formatted_results = []
            for doc, score in results:
                formatted_results.append({
                    'content': doc.page_content,
                    'metadata': doc.metadata,
                    'relevance_score': float(score)
                })
            return formatted_results
        except Exception as e:
            print(f"Error in semantic search: {e}")
            return []
    
    def query_with_llm(self, query: str, k: int = 3) -> Dict[str, Any]:
        """Answer a query using RAG: retrieve relevant emails and generate response with Groq LLM."""
        if not self.llm:
            return {
                'error': 'LLM not initialized. Please provide GROQ_API_KEY.',
                'query': query
            }
        try:
            relevant_docs = self.semantic_search(query, k=k)
            if not relevant_docs:
                return {
                    'answer': 'No relevant information found in your emails.',
                    'sources': [],
                    'query': query
                }
            context = "\n\n".join([f"Email {i+1}:\n{doc['content']}" for i, doc in enumerate(relevant_docs)])
            prompt = f"""Based on the following emails from the user's inbox, please answer the question.
EMAILS:
{context}
QUESTION: {query}
Please provide a helpful and accurate answer based on the email content above. If the emails don't contain enough information to answer the question, say so."""
            from langchain_core.messages import HumanMessage
            response = self.llm.invoke([HumanMessage(content=prompt)])
            return {
                'answer': response.content,
                'sources': relevant_docs,
                'query': query,
                'num_sources': len(relevant_docs)
            }
        except Exception as e:
            print(f"Error in query_with_llm: {e}")
            return {'error': str(e), 'query': query}
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about the RAG system."""
        try:
            count = 0
            if self.vectorstore:
                count = self.vectorstore._collection.count()
            return {
                'total_chunks': count,
                'persist_directory': self.persist_directory,
                'embedding_model': 'sentence-transformers/all-MiniLM-L6-v2',
                'llm_configured': self.llm is not None,
                'rag_enabled': self.vectorstore is not None
            }
        except Exception as e:
            return {'error': str(e)}
