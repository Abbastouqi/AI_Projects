// GIKI Student Services Platform - Main JavaScript

// Global variables
let currentUser = null;
let notifications = [];
let websocket = null;

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    checkNotifications();
});

function initializeApp() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Setup auto-refresh for dynamic content
    setupAutoRefresh();
    
    // Initialize service worker for offline support
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/static/js/sw.js').catch(console.error);
    }
}

function setupEventListeners() {
    // Global error handler
    window.addEventListener('error', function(e) {
        console.error('Global error:', e.error);
        showNotification('An error occurred. Please refresh the page.', 'error');
    });
    
    // Network status monitoring
    window.addEventListener('online', function() {
        showNotification('Connection restored', 'success');
    });
    
    window.addEventListener('offline', function() {
        showNotification('Connection lost. Some features may not work.', 'warning');
    });
    
    // Handle form submissions with AJAX
    document.querySelectorAll('form[data-ajax]').forEach(form => {
        form.addEventListener('submit', handleAjaxForm);
    });
    
    // Handle smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Handle keyboard shortcuts
    setupKeyboardShortcuts();
}

function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + K for search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            focusSearchInput();
        }
        
        // Escape to close modals
        if (e.key === 'Escape') {
            const openModal = document.querySelector('.modal.show');
            if (openModal) {
                bootstrap.Modal.getInstance(openModal).hide();
            }
        }
    });
}

function focusSearchInput() {
    const searchInput = document.querySelector('input[type="search"], #locationSearch, #complaintDescription');
    if (searchInput) {
        searchInput.focus();
        searchInput.select();
    }
}

// Notification System
function showNotification(message, type = 'info', duration = 5000) {
    const notificationContainer = document.getElementById('notificationContainer') || createNotificationContainer();
    
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show notification-item`;
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    notificationContainer.appendChild(notification);
    
    // Auto-remove after duration
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, duration);
    
    // Add entrance animation
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
}

function createNotificationContainer() {
    const container = document.createElement('div');
    container.id = 'notificationContainer';
    container.className = 'notification-container position-fixed top-0 end-0 p-3';
    container.style.zIndex = '9999';
    document.body.appendChild(container);
    return container;
}

function checkNotifications() {
    // Check for server-sent events or polling for notifications
    if (typeof(EventSource) !== "undefined") {
        const eventSource = new EventSource('/api/notifications');
        
        eventSource.onmessage = function(event) {
            const data = JSON.parse(event.data);
            showNotification(data.message, data.type);
        };
        
        eventSource.onerror = function() {
            console.log('Notification connection error');
            eventSource.close();
        };
    }
}

// AJAX Form Handler
function handleAjaxForm(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    const submitButton = form.querySelector('button[type="submit"]');
    
    // Show loading state
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
    submitButton.disabled = true;
    
    fetch(form.action || form.getAttribute('data-url'), {
        method: form.method || 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification(data.message || 'Operation completed successfully', 'success');
            
            // Reset form if requested
            if (form.getAttribute('data-reset') === 'true') {
                form.reset();
            }
            
            // Redirect if specified
            if (data.redirect) {
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1500);
            }
        } else {
            showNotification(data.error || 'Operation failed', 'error');
        }
    })
    .catch(error => {
        console.error('Form submission error:', error);
        showNotification('An error occurred. Please try again.', 'error');
    })
    .finally(() => {
        // Restore button state
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
    });
}

// Auto-refresh functionality
function setupAutoRefresh() {
    // Auto-refresh dashboard stats every 30 seconds
    if (window.location.pathname === '/dashboard') {
        setInterval(() => {
            updateDashboardStats();
        }, 30000);
    }
    
    // Auto-refresh order status every 10 seconds
    if (window.location.pathname === '/food') {
        setInterval(() => {
            updateOrderStatus();
        }, 10000);
    }
}

function updateDashboardStats() {
    fetch('/api/dashboard/stats')
        .then(response => response.json())
        .then(data => {
            // Update email count
            const emailCount = document.getElementById('unreadCount');
            if (emailCount && data.emails !== undefined) {
                const count = Math.max(0, data.emails); // Prevent negative numbers
                emailCount.textContent = count;
                animateNumber(emailCount);
            }
            
            // Update complaint count
            const complaintCount = document.getElementById('complaintCount');
            if (complaintCount && data.complaints !== undefined) {
                const count = Math.max(0, data.complaints); // Prevent negative numbers
                complaintCount.textContent = count;
                animateNumber(complaintCount);
            }
            
            // Update order count
            const orderCount = document.getElementById('orderCount');
            if (orderCount && data.orders !== undefined) {
                const count = Math.max(0, data.orders); // Prevent negative numbers
                orderCount.textContent = count;
                animateNumber(orderCount);
            }
        })
        .catch(error => console.error('Error updating dashboard stats:', error));
}

function updateOrderStatus() {
    const orderId = document.querySelector('[data-order-id]');
    if (!orderId) return;
    
    fetch(`/api/order/${orderId.dataset.orderId}/status`)
        .then(response => response.json())
        .then(data => {
            updateOrderProgress(data.progress);
            updateOrderSteps(data.steps);
        })
        .catch(error => console.error('Error updating order status:', error));
}

function updateOrderProgress(progress) {
    const progressBar = document.getElementById('orderProgress');
    if (progressBar) {
        progressBar.style.width = progress + '%';
    }
}

function updateOrderSteps(steps) {
    steps.forEach((step, index) => {
        const stepElement = document.getElementById(`step-${index}`);
        if (stepElement) {
            stepElement.className = step.completed ? 'fas fa-check-circle text-success' : 'fas fa-clock text-muted';
        }
    });
}

// Number animation
function animateNumber(element) {
    const target = parseInt(element.textContent);
    const current = parseInt(element.dataset.current) || 0;
    
    // If no animation needed, just set the value
    if (target === current) {
        element.dataset.current = target;
        return;
    }
    
    const increment = target > current ? 1 : -1;
    const duration = 500;
    const steps = Math.abs(target - current);
    const stepDuration = duration / steps;
    
    let value = current;
    const timer = setInterval(() => {
        value += increment;
        element.textContent = value;
        element.dataset.current = value;
        
        if (value === target) {
            clearInterval(timer);
        }
    }, stepDuration);
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Format functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-PK', {
        style: 'currency',
        currency: 'PKR'
    }).format(amount);
}

function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('en-PK', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatRelativeTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    return 'Just now';
}

// Validation functions
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[\d\s\-\+\(\)]+$/;
    return re.test(phone) && phone.replace(/\D/g, '').length >= 10;
}

function validateRollNumber(rollNumber) {
    const re = /^u\d{7}$/;
    return re.test(rollNumber);
}

// Storage functions
function setLocalStorage(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
        console.error('LocalStorage error:', e);
    }
}

function getLocalStorage(key, defaultValue = null) {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (e) {
        console.error('LocalStorage error:', e);
        return defaultValue;
    }
}

function removeLocalStorage(key) {
    try {
        localStorage.removeItem(key);
    } catch (e) {
        console.error('LocalStorage error:', e);
    }
}

// Geolocation functions
function getCurrentPosition() {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
            reject(new Error('Geolocation not supported'));
            return;
        }
        
        navigator.geolocation.getCurrentPosition(
            position => resolve(position),
            error => reject(error),
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 300000
            }
        );
    });
}

function watchPosition(callback, errorCallback) {
    if (!navigator.geolocation) {
        errorCallback(new Error('Geolocation not supported'));
        return null;
    }
    
    return navigator.geolocation.watchPosition(
        callback,
        errorCallback,
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000
        }
    );
}

// Camera functions
function requestCameraAccess() {
    return navigator.mediaDevices.getUserMedia({
        video: {
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
        }
    });
}

// Voice recognition
function startVoiceRecognition() {
    return new Promise((resolve, reject) => {
        if (!('webkitSpeechRecognition' in window)) {
            reject(new Error('Speech recognition not supported'));
            return;
        }
        
        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';
        
        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            resolve(transcript);
        };
        
        recognition.onerror = (event) => {
            reject(new Error(event.error));
        };
        
        recognition.onend = () => {
            recognition.stop();
        };
        
        recognition.start();
    });
}

// Image processing
function compressImage(file, maxWidth = 800, maxHeight = 600, quality = 0.8) {
    return new Promise((resolve) => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();
        
        img.onload = () => {
            let width = img.width;
            let height = img.height;
            
            // Calculate new dimensions
            if (width > maxWidth || height > maxHeight) {
                const ratio = Math.min(maxWidth / width, maxHeight / height);
                width *= ratio;
                height *= ratio;
            }
            
            canvas.width = width;
            canvas.height = height;
            
            // Draw and compress
            ctx.drawImage(img, 0, 0, width, height);
            canvas.toBlob(resolve, 'image/jpeg', quality);
        };
        
        img.src = URL.createObjectURL(file);
    });
}

// Export functions for global use
window.GIKIServices = {
    showNotification,
    getCurrentPosition,
    requestCameraAccess,
    startVoiceRecognition,
    compressImage,
    formatCurrency,
    formatDateTime,
    formatRelativeTime,
    validateEmail,
    validatePhone,
    validateRollNumber,
    setLocalStorage,
    getLocalStorage,
    removeLocalStorage
};

// Performance monitoring
if ('performance' in window) {
    window.addEventListener('load', () => {
        const perfData = performance.getEntriesByType('navigation')[0];
        console.log('Page load time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
    });
}

// Service Worker registration for offline support
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/static/js/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}
