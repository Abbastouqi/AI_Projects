/**
 * Dark Mode and UI Enhancement Manager
 * Handles theme switching, scroll animations, and UI improvements
 */

class UIEnhancementManager {
    constructor() {
        this.theme = localStorage.getItem('theme') || 'light';
        this.themeToggle = null;
    }

    init() {
        // Apply saved theme
        this.applyTheme(this.theme);

        // Create theme toggle button
        this.createThemeToggle();

        // Initialize scroll animations
        this.initScrollAnimations();

        // Initialize tooltips
        this.initTooltips();

        // Add smooth transitions to all elements
        this.addSmoothTransitions();
    }

    createThemeToggle() {
        // Create toggle button
        this.themeToggle = document.createElement('button');
        this.themeToggle.className = 'theme-toggle';
        this.themeToggle.setAttribute('aria-label', 'Toggle Dark Mode');
        this.themeToggle.innerHTML = this.theme === 'dark'
            ? '<i class="fas fa-sun"></i>'
            : '<i class="fas fa-moon"></i>';

        this.themeToggle.addEventListener('click', () => this.toggleTheme());

        document.body.appendChild(this.themeToggle);
    }

    toggleTheme() {
        this.theme = this.theme === 'light' ? 'dark' : 'light';
        this.applyTheme(this.theme);
        localStorage.setItem('theme', this.theme);

        // Update icon
        this.themeToggle.innerHTML = this.theme === 'dark'
            ? '<i class="fas fa-sun"></i>'
            : '<i class="fas fa-moon"></i>';

        // Animate transition
        this.themeToggle.classList.add('scale-in');
        setTimeout(() => this.themeToggle.classList.remove('scale-in'), 400);
    }

    applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);

        // Update meta theme-color for mobile browsers
        let metaTheme = document.querySelector('meta[name="theme-color"]');
        if (!metaTheme) {
            metaTheme = document.createElement('meta');
            metaTheme.name = 'theme-color';
            document.head.appendChild(metaTheme);
        }
        metaTheme.content = theme === 'dark' ? '#1a1a2e' : '#ffffff';
    }

    initScrollAnimations() {
        // Get all elements that should animate on scroll
        const elements = document.querySelectorAll('.scroll-reveal');

        if (elements.length === 0) return;

        // Create intersection observer
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    // Unobserve after revealing to improve performance
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });

        // Observe all elements
        elements.forEach(el => observer.observe(el));
    }

    initTooltips() {
        // Enable Bootstrap tooltips if available
        if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
            const tooltipTriggerList = [].slice.call(
                document.querySelectorAll('[data-bs-toggle="tooltip"]')
            );
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        }
    }

    addSmoothTransitions() {
        // Add smooth transitions to cards on page load
        const cards = document.querySelectorAll('.card');
        cards.forEach((card, index) => {
            // Stagger animation
            setTimeout(() => {
                card.classList.add('fade-in');
            }, index * 50);
        });
    }

    showLoadingSkeleton(container, type = 'card', count = 3) {
        const skeletons = [];

        for (let i = 0; i < count; i++) {
            const skeleton = document.createElement('div');

            if (type === 'card') {
                skeleton.innerHTML = `
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="skeleton skeleton-title"></div>
                            <div class="skeleton skeleton-text"></div>
                            <div class="skeleton skeleton-text" style="width: 80%;"></div>
                        </div>
                    </div>
                `;
            } else if (type === 'text') {
                skeleton.innerHTML = `
                    <div class="skeleton skeleton-text mb-2"></div>
                    <div class="skeleton skeleton-text mb-2"></div>
                    <div class="skeleton skeleton-text" style="width:70%;"></div>
                `;
            }

            skeletons.push(skeleton);
        }

        container.innerHTML = '';
        skeletons.forEach(s => container.appendChild(s));
    }

    hideLoadingSkeleton(container, content) {
        container.innerHTML = content;
        container.querySelectorAll('.card').forEach((card, i) => {
            setTimeout(() => card.classList.add('scale-in'), i * 100);
        });
    }

    showSpinner(container) {
        container.innerHTML = `
            <div class="text-center py-5">
                <div class="spinner-primary mx-auto"></div>
                <p class="mt-3 text-muted">Loading...</p>
            </div>
        `;
    }

    showDotsLoader(container) {
        container.innerHTML = `
            <div class="text-center py-5">
                <div class="dots-loader">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
    }

    addGlassmorphism(element) {
        element.classList.add('glass-card');
        if (this.theme === 'dark') {
            element.classList.add('glass-card-dark');
        }
    }

    createNotification(message, type = 'info', duration = 3000) {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} position-fixed top-0 end-0 m-3 fade-in`;
        notification.style.zIndex = '9999';
        notification.style.minWidth = '300px';
        notification.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="fas fa-${this.getIconForType(type)} me-2"></i>
                <div>${message}</div>
                <button type="button" class="btn-close ms-auto" onclick="this.parentElement.parentElement.remove()"></button>
            </div>
        `;

        document.body.appendChild(notification);

        // Auto-remove after duration
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => notification.remove(), 300);
        }, duration);
    }

    getIconForType(type) {
        const icons = {
            'success': 'check-circle',
            'error': 'exclamation-circle',
            'warning': 'exclamation-triangle',
            'info': 'info-circle',
            'danger': 'exclamation-circle'
        };
        return icons[type] || 'info-circle';
    }
}

// Initialize UI enhancements when DOM is ready
let uiManager;

document.addEventListener('DOMContentLoaded', function () {
    uiManager = new UIEnhancementManager();
    uiManager.init();

    console.log('UI Enhancement Manager initialized');
});

// Global helper functions
function showNotification(message, type = 'info') {
    if (uiManager) {
        uiManager.createNotification(message, type);
    }
}

function showLoading(containerId, type = 'spinner') {
    const container = document.getElementById(containerId);
    if (!container || !uiManager) return;

    if (type === 'spinner') {
        uiManager.showSpinner(container);
    } else if (type === 'dots') {
        uiManager.showDotsLoader(container);
    } else if (type === 'skeleton') {
        uiManager.showLoadingSkeleton(container, 'card', 3);
    }
}

function hideLoading(containerId, content) {
    const container = document.getElementById(containerId);
    if (!container || !uiManager) return;

    uiManager.hideLoadingSkeleton(container, content);
}

// Keyboard shortcuts
document.addEventListener('keydown', function (e) {
    // Ctrl/Cmd + D to toggle dark mode
    if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
        e.preventDefault();
        if (uiManager) {
            uiManager.toggleTheme();
        }
    }
});

// Add smooth scroll behavior
document.documentElement.style.scrollBehavior = 'smooth';

// Lazy load images for better performance
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img.lazy').forEach(img => {
        imageObserver.observe(img);
    });
}

// Add ripple effect to buttons
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('btn') || e.target.closest('.btn')) {
        const button = e.target.classList.contains('btn') ? e.target : e.target.closest('.btn');

        const ripple = document.createElement('span');
        const rect = button.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;

        ripple.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            left: ${x}px;
            top: ${y}px;
            background: rgba(255,255,255,0.5);
            border-radius: 50%;
            transform: scale(0);
            animation: ripple-animation 0.6s ease-out;
            pointer-events: none;
        `;

        button.style.position = 'relative';
        button.style.overflow = 'hidden';
        button.appendChild(ripple);

        setTimeout(() => ripple.remove(), 600);
    }
});

// Add ripple animation
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Performance monitoring (development only)
if (window.location.hostname === 'localhost') {
    window.addEventListener('load', function () {
        const perfData = window.performance.timing;
        const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
        console.log(`Page Load Time: ${pageLoadTime}ms`);
    });
}
