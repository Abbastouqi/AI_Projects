/**
 * Enhanced AR Navigation System for GIKI Campus
 * Features: HUD display, compass alignment, distance/ETA, smooth animations
 */

class ARNavigationSystem {
    constructor() {
        this.isActive = false;
        this.destination = null;
        this.currentPosition = null;
        this.compassHeading = 0;
        this.camera = null;
        this.videoElement = null;
        this.canvasElement = null;
        this.ctx = null;

        // AR overlay elements
        this.arContainer = null;
        this.hudElements = {};

        // Animation
        this.animationFrame = null;

        // Settings
        this.settings = {
            arrowColor: '#667eea',
            hudColor: '#ffffff',
            nightMode: false,
            showDistance: true,
            showETA: true,
            showCompass: true
        };
    }

    async initialize() {
        console.log('Initializing AR Navigation System...');

        // Check for required APIs
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            throw new Error('Camera API not supported');
        }

        if (!window.DeviceOrientationEvent) {
            console.warn('Device Orientation API not supported');
        }

        // Request camera permissions
        try {
            this.camera = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: 'environment', width: 1280, height: 720 }
            });
            console.log('Camera access granted');
            return true;
        } catch (error) {
            console.error('Camera access denied:', error);
            throw new Error('Camera access required for AR navigation');
        }
    }

    async start(destination) {
        if (!this.camera) {
            await this.initialize();
        }

        this.destination = destination;
        this.isActive = true;

        // Create AR UI
        this.createARInterface();

        // Start camera stream
        this.videoElement.srcObject = this.camera;
        await this.videoElement.play();

        // Start tracking
        this.startPositionTracking();
        this.startCompassTracking();

        // Start rendering
        this.render();

        console.log('AR Navigation started for:', destination);
    }

    stop() {
        this.isActive = false;

        // Stop camera
        if (this.camera) {
            this.camera.getTracks().forEach(track => track.stop());
        }

        // Stop animation
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
        }

        // Remove UI
        if (this.arContainer) {
            this.arContainer.remove();
        }

        console.log('AR Navigation stopped');
    }

    createARInterface() {
        // Create AR container
        this.arContainer = document.createElement('div');
        this.arContainer.id = 'ar-navigation-container';
        this.arContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 9999;
            background: #0a0a0a;
            font-family: 'Inter', -apple-system, sans-serif;
        `;

        // Video element (camera feed)
        this.videoElement = document.createElement('video');
        this.videoElement.style.cssText = `
            width: 100%;
            height: 100%;
            object-fit: cover;
            filter: contrast(1.1) brightness(0.9);
        `;
        this.videoElement.setAttribute('playsinline', '');
        this.arContainer.appendChild(this.videoElement);

        // Canvas for AR overlays
        this.canvasElement = document.createElement('canvas');
        this.canvasElement.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
        `;
        this.arContainer.appendChild(this.canvasElement);

        // Set canvas size
        this.canvasElement.width = window.innerWidth;
        this.canvasElement.height = window.innerHeight;
        this.ctx = this.canvasElement.getContext('2d');

        // HUD Elements
        this.createHUD();

        // Premium Exit Button
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '<i class="fas fa-times"></i>';
        closeBtn.style.cssText = `
            position: absolute;
            top: 30px;
            right: 30px;
            width: 54px;
            height: 54px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.2);
            font-size: 20px;
            cursor: pointer;
            z-index: 100;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
        `;
        closeBtn.onmouseover = () => { closeBtn.style.background = 'rgba(239, 68, 68, 0.6)'; };
        closeBtn.onmouseout = () => { closeBtn.style.background = 'rgba(255, 255, 255, 0.1)'; };
        closeBtn.onclick = () => this.stop();
        this.arContainer.appendChild(closeBtn);

        document.body.appendChild(this.arContainer);
    }

    createHUD() {
        const hudContainer = document.createElement('div');
        hudContainer.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            overflow: hidden;
        `;

        // 1. Top Compass Ribbon
        const ribbonHeight = 60;
        const ribbon = document.createElement('div');
        ribbon.style.cssText = `
            position: absolute;
            top: 30px;
            left: 50%;
            transform: translateX(-50%);
            width: 260px;
            height: ${ribbonHeight}px;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(20px);
            border-radius: 30px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 25px;
            color: white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.5);
        `;
        ribbon.innerHTML = `
            <div style="display: flex; flex-direction: column; align-items: center;">
                <span style="font-size: 10px; opacity: 0.6; text-transform: uppercase; letter-spacing: 1px;">Heading</span>
                <span id="ar-heading-val" style="font-weight: 700; font-size: 18px;">---°</span>
            </div>
            <div style="width: 1px; height: 30px; background: rgba(255,255,255,0.1);"></div>
            <div style="display: flex; flex-direction: column; align-items: center;">
                <span style="font-size: 10px; opacity: 0.6; text-transform: uppercase; letter-spacing: 1px;">Target</span>
                <span id="ar-direction-txt" style="font-weight: 700; font-size: 18px;">NW</span>
            </div>
        `;
        this.hudElements.headingVal = ribbon.querySelector('#ar-heading-val');
        this.hudElements.directionTxt = ribbon.querySelector('#ar-direction-txt');
        hudContainer.appendChild(ribbon);

        // 2. Middle HUD: Destination info (Pulsing badge)
        const destBadge = document.createElement('div');
        destBadge.style.cssText = `
            position: absolute;
            top: 110px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(135deg, rgba(74, 144, 226, 0.3), rgba(126, 211, 33, 0.3));
            backdrop-filter: blur(10px);
            padding: 8px 20px;
            border-radius: 20px;
            border: 1px solid rgba(255,255,255,0.2);
            color: white;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: pulse-border 2s infinite;
        `;
        destBadge.innerHTML = `<i class="fas fa-location-arrow" style="color: #4ae37d;"></i> ${this.destination.name}`;
        hudContainer.appendChild(destBadge);

        // 3. Bottom Stats Grid (Glassmorphism cards)
        const bottomGrid = document.createElement('div');
        bottomGrid.style.cssText = `
            position: absolute;
            bottom: 60px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 15px;
            width: calc(100% - 60px);
            max-width: 500px;
        `;

        const createCard = (label, valueId, icon, color) => {
            const card = document.createElement('div');
            card.style.cssText = `
                flex: 1;
                background: rgba(255, 255, 255, 0.05);
                backdrop-filter: blur(25px);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 20px;
                padding: 15px;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 5px;
                box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.2);
            `;
            card.innerHTML = `
                <i class="${icon}" style="color: ${color}; font-size: 16px;"></i>
                <div id="${valueId}" style="color: white; font-weight: 700; font-size: 20px;">--</div>
                <div style="color: rgba(255,255,255,0.5); font-size: 9px; text-transform: uppercase;">${label}</div>
            `;
            return card;
        };

        const distCard = createCard('Distance', 'ar-grid-dist', 'fas fa-ruler-horizontal', '#00f2fe');
        const etaCard = createCard('Arrival', 'ar-grid-eta', 'fas fa-clock', '#4ae37d');
        const accuracyCard = createCard('GPS', 'ar-grid-acc', 'fas fa-satellite', '#ff0844');

        this.hudElements.distVal = distCard.querySelector('#ar-grid-dist');
        this.hudElements.etaVal = etaCard.querySelector('#ar-grid-eta');
        this.hudElements.accVal = accuracyCard.querySelector('#ar-grid-acc');

        bottomGrid.append(distCard, etaCard, accuracyCard);
        hudContainer.appendChild(bottomGrid);

        // 4. Scanning Radar UI
        const radar = document.createElement('div');
        radar.style.cssText = `
            position: absolute;
            left: 30px;
            top: 30px;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 1px solid rgba(0, 242, 254, 0.3);
            background: radial-gradient(circle, rgba(0, 242, 254, 0.1) 0%, transparent 70%);
            display: flex;
            align-items: center;
            justify-content: center;
        `;
        radar.innerHTML = `
            <div style="position: absolute; width: 100%; height: 100%; border-radius: 50%; border: 1px solid rgba(0, 242, 254, 0.1); animation: radar-spin 4s linear infinite;"></div>
            <div style="position: absolute; width: 50%; height: 50%; border-radius: 50%; border: 1px solid rgba(0, 242, 254, 0.2);"></div>
            <i class="fas fa-crosshairs" style="color: #00f2fe; font-size: 12px; opacity: 0.5;"></i>
        `;
        hudContainer.appendChild(radar);

        // Add Animations to Stylesheet
        const style = document.createElement('style');
        style.textContent = `
            @keyframes pulse-border {
                0% { box-shadow: 0 0 0 0 rgba(74, 144, 226, 0.4); }
                70% { box-shadow: 0 0 0 10px rgba(74, 144, 226, 0); }
                100% { box-shadow: 0 0 0 0 rgba(74, 144, 226, 0); }
            }
            @keyframes radar-spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);

        this.arContainer.appendChild(hudContainer);
    }

    startPositionTracking() {
        if (!navigator.geolocation) return;

        this.positionWatcher = navigator.geolocation.watchPosition(
            (position) => {
                this.currentPosition = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                    accuracy: position.coords.accuracy
                };
                this.updateDistanceAndETA();
                if (this.hudElements.accVal) {
                    this.hudElements.accVal.textContent = `${Math.round(position.coords.accuracy)}m`;
                }
            },
            (error) => console.error('Position error:', error),
            { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
        );
    }

    startCompassTracking() {
        if (window.DeviceOrientationEvent) {
            window.addEventListener('deviceorientation', (event) => {
                let heading = event.alpha || 0;
                if (event.webkitCompassHeading) {
                    heading = event.webkitCompassHeading;
                }
                this.compassHeading = heading;
                this.updateCompass();
            });
        }
    }

    updateDistanceAndETA() {
        if (!this.currentPosition || !this.destination) return;

        const distance = this.calculateDistance(
            this.currentPosition.lat,
            this.currentPosition.lng,
            this.destination.latitude,
            this.destination.longitude
        );

        if (this.hudElements.distVal) {
            if (distance < 1) {
                this.hudElements.distVal.textContent = `${Math.round(distance * 1000)}m`;
            } else {
                this.hudElements.distVal.textContent = `${distance.toFixed(1)}km`;
            }
        }

        const walkingSpeed = 5;
        const etaMinutes = Math.round((distance / walkingSpeed) * 60);

        if (this.hudElements.etaVal) {
            this.hudElements.etaVal.textContent = etaMinutes < 1 ? '1m' : `${etaMinutes}m`;
        }
    }

    updateCompass() {
        if (this.hudElements.headingVal) {
            this.hudElements.headingVal.textContent = `${Math.round(this.compassHeading)}°`;
        }

        const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
        const index = Math.round(this.compassHeading / 45) % 8;
        if (this.hudElements.directionTxt) {
            this.hudElements.directionTxt.textContent = directions[index];
        }
    }

    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = this.toRad(lat2 - lat1);
        const dLon = this.toRad(lon2 - lon1);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    toRad(degrees) { return degrees * Math.PI / 180; }

    calculateBearing(lat1, lon1, lat2, lon2) {
        const dLon = this.toRad(lon2 - lon1);
        const y = Math.sin(dLon) * Math.cos(this.toRad(lat2));
        const x = Math.cos(this.toRad(lat1)) * Math.sin(this.toRad(lat2)) -
            Math.sin(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) * Math.cos(dLon);
        return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
    }

    render() {
        if (!this.isActive) return;
        this.ctx.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);

        if (this.currentPosition && this.destination) {
            const bearing = this.calculateBearing(
                this.currentPosition.lat,
                this.currentPosition.lng,
                this.destination.latitude,
                this.destination.longitude
            );
            const arrowAngle = bearing - this.compassHeading;
            this.drawDirectionalArrow(arrowAngle);
            this.drawScanlines();
        }

        this.animationFrame = requestAnimationFrame(() => this.render());
    }

    drawDirectionalArrow(angle) {
        const centerX = this.canvasElement.width / 2;
        const centerY = this.canvasElement.height / 2;
        const time = Date.now() / 1000;
        const hoverOffset = Math.sin(time * 3) * 10;

        this.ctx.save();
        this.ctx.translate(centerX, centerY + hoverOffset);
        this.ctx.rotate(angle * Math.PI / 180);

        // Glow effect
        this.ctx.shadowBlur = 40;
        this.ctx.shadowColor = 'rgba(74, 144, 226, 0.8)';

        // Gradient Arrow
        const gradient = this.ctx.createLinearGradient(0, -100, 0, 100);
        gradient.addColorStop(0, '#00f2fe');
        gradient.addColorStop(1, '#667eea');

        this.ctx.fillStyle = gradient;
        this.ctx.strokeStyle = 'white';
        this.ctx.lineWidth = 4;

        this.ctx.beginPath();
        this.ctx.moveTo(0, -90);
        this.ctx.lineTo(-45, 45);
        this.ctx.lineTo(0, 25);
        this.ctx.lineTo(45, 45);
        this.ctx.closePath();

        this.ctx.fill();
        this.ctx.stroke();
        this.ctx.restore();
    }

    drawScanlines() {
        const time = Date.now() / 2000;
        const scanlineY = (time % 1) * this.canvasElement.height;

        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.moveTo(0, scanlineY);
        this.ctx.lineTo(this.canvasElement.width, scanlineY);
        this.ctx.strokeStyle = 'rgba(0, 242, 254, 0.1)';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
        this.ctx.restore();
    }

    toggleNightMode() {
        this.settings.nightMode = !this.settings.nightMode;
        this.videoElement.style.filter = this.settings.nightMode ? 'brightness(0.6) contrast(1.2) sepia(0.2) hue-rotate(180deg)' : 'brightness(0.9) contrast(1.1)';
    }
}

window.arNavigation = new ARNavigationSystem();

function startARNavigation(destination) {
    if (!destination && window.currentDestination) {
        destination = {
            name: document.getElementById('locationSearch')?.value || 'Destination',
            latitude: window.currentDestination.lat,
            longitude: window.currentDestination.lng
        };
    }
    window.arNavigation.start(destination).catch(err => {
        alert('AR Permission required: ' + err.message);
    });
}

function stopARNavigation() { window.arNavigation.stop(); }

