#!/usr/bin/env python3
"""
Event Extraction System for GIKI Student Services Platform

This module extracts events, seminars, concerts, and workshops from Outlook emails
using NLP and pattern matching.
"""

import re
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
import json

from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage


class EventExtractor:
    """Extract structured event information from emails."""
    
    # Event type keywords
    EVENT_KEYWORDS = {
        'seminar': ['seminar', 'talk', 'lecture', 'presentation', 'speaker'],
        'workshop': ['workshop', 'training', 'hands-on', 'tutorial'],
        'concert': ['concert', 'music', 'performance', 'show'],
        'conference': ['conference', 'symposium', 'summit'],
        'competition': ['competition', 'contest', 'hackathon'],
        'ceremony': ['ceremony', 'graduation', 'convocation'],
        'meeting': ['meeting', 'gathering', 'assembly'],
        'sports': ['match', 'game', 'tournament', 'sports'],
        'cultural': ['cultural', 'fest', 'festival', 'celebration']
    }
    
    # Date patterns
    DATE_PATTERNS = [
        r'\b(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\b',  # DD/MM/YYYY or DD-MM-YYYY
        r'\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* (\d{1,2}),? (\d{4})\b',  # Month DD, YYYY
        r'\b(\d{1,2}) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* (\d{4})\b',  # DD Month YYYY
        r'\b(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),? (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* (\d{1,2})\b',  # Day, Month DD
    ]
    
    # Time patterns
    TIME_PATTERNS = [
        r'\b(\d{1,2}):(\d{2})\s*(AM|PM|am|pm)\b',  # 2:30 PM
        r'\b(\d{1,2})\s*(AM|PM|am|pm)\b',  # 2 PM
        r'\b(\d{1,2}):(\d{2})\b',  # 14:30 (24-hour)
    ]
    
    # Location patterns (GIKI-specific)
    LOCATION_PATTERNS = [
        r'(?:in|at)\s+(Lecture Hall [A-Z\d]+)',
        r'(?:in|at)\s+(Computer Lab [A-Z\d]+)',
        r'(?:in|at)\s+(Auditorium)',
        r'(?:in|at)\s+(Library)',
        r'(?:in|at)\s+(Mess Hall)',
        r'(?:in|at)\s+(Student Center)',
        r'(?:in|at)\s+([A-Z][A-Za-z\s]+Building)',
    ]
    
    def __init__(self, groq_api_key: Optional[str] = None):
        """Initialize event extractor.
        
        Args:
            groq_api_key: Optional API key for Groq LLM for advanced extraction
        """
        self.groq_api_key = groq_api_key
        self.llm = None
        
        if groq_api_key:
            try:
                self.llm = ChatGroq(
                    groq_api_key=groq_api_key,
                    model_name="llama-3.1-70b-versatile",
                    temperature=0.1
                )
            except Exception as e:
                print(f"Failed to initialize Groq LLM for event extraction: {e}")
    
    def is_event_email(self, email: Dict[str, Any]) -> bool:
        """Check if an email contains event information.
        
        Args:
            email: Email dictionary
            
        Returns:
            True if email likely contains event info
        """
        subject = email.get('subject', '').lower()
        body = email.get('body', {}).get('content', '') or email.get('bodyPreview', '')
        body = body.lower()
        
        # Check for event keywords in subject or body
        for event_type, keywords in self.EVENT_KEYWORDS.items():
            for keyword in keywords:
                if keyword in subject or keyword in body:
                    return True
        
        # Check for invitation/announcement keywords
        invitation_keywords = ['invited', 'invitation', 'announce', 'announcement', 'upcoming', 'save the date']
        for keyword in invitation_keywords:
            if keyword in subject or keyword in body:
                return True
        
        return False
    
    def extract_event_type(self, text: str) -> str:
        """Extract event type from text.
        
        Args:
            text: Email subject or body
            
        Returns:
            Event type (seminar, workshop, etc.) or 'other'
        """
        text_lower = text.lower()
        
        for event_type, keywords in self.EVENT_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text_lower:
                    return event_type
        
        return 'other'
    
    def extract_dates(self, text: str) -> List[str]:
        """Extract dates from text.
        
        Args:
            text: Email body or subject
            
        Returns:
            List of date strings found
        """
        dates = []
        
        for pattern in self.DATE_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                dates.append(' '.join(match) if isinstance(match, tuple) else match)
        
        return dates
    
    def extract_times(self, text: str) -> List[str]:
        """Extract times from text.
        
        Args:
            text: Email body or subject
            
        Returns:
            List of time strings found
        """
        times = []
        
        for pattern in self.TIME_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                times.append(' '.join(match) if isinstance(match, tuple) else match)
        
        return times
    
    def extract_location(self, text: str) -> Optional[str]:
        """Extract location from text.
        
        Args:
            text: Email body or subject
            
        Returns:
            Location string or None
        """
        for pattern in self.LOCATION_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return None
    
    def extract_organizer(self, email: Dict[str, Any]) -> str:
        """Extract event organizer from email.
        
        Args:
            email: Email dictionary
            
        Returns:
            Organizer name/email
        """
        sender = email.get('from', {}).get('emailAddress', {})
        name = sender.get('name', '')
        address = sender.get('address', '')
        
        # Check if it's a department email
        body = email.get('body', {}).get('content', '') or email.get('bodyPreview', '')
        
        # Look for "organized by" or "hosted by" patterns
        org_match = re.search(r'(?:organized|hosted|presented) by ([A-Za-z\s]+(?:Department|Society|Club))', body, re.IGNORECASE)
        if org_match:
            return org_match.group(1)
        
        return name or address
    
    def extract_event_simple(self, email: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Extract event information using pattern matching.
        
        Args:
            email: Email dictionary from Outlook API
            
        Returns:
            Event dictionary or None if no event found
        """
        if not self.is_event_email(email):
            return None
        
        subject = email.get('subject', '')
        body = email.get('body', {}).get('content', '') or email.get('bodyPreview', '')
        full_text = f"{subject}\n\n{body}"
        
        # Extract components
        event_type = self.extract_event_type(full_text)
        dates = self.extract_dates(full_text)
        times = self.extract_times(full_text)
        location = self.extract_location(full_text)
        organizer = self.extract_organizer(email)
        
        # Create event object
        event = {
            'title': subject,
            'type': event_type,
            'description': body[:500],  # First 500 chars
            'date': dates[0] if dates else None,
            'time': times[0] if times else None,
            'location': location,
            'organizer': organizer,
            'source_email_id': email.get('id'),
            'source_email_subject': subject,
            'extracted_at': datetime.now().isoformat()
        }
        
        return event
    
    def extract_event_with_llm(self, email: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Extract event information using LLM for better accuracy.
        
        Args:
            email: Email dictionary from Outlook API
            
        Returns:
            Event dictionary or None
        """
        if not self.llm or not self.is_event_email(email):
            return self.extract_event_simple(email)
        
        subject = email.get('subject', '')
        body = email.get('body', {}).get('content', '') or email.get('bodyPreview', '')
        
        prompt = f"""Extract event information from the following email. Return a JSON object with these fields:
- title: Event title/name
- type: Event type (seminar, workshop, concert, conference, competition, ceremony, meeting, sports, cultural, or other)
- description: Brief description (max 200 chars)
- date: Event date in YYYY-MM-DD format if available
- time: Event time in HH:MM format if available
- location: Event location
- organizer: Who is organizing/hosting
- registration_required: true/false if registration is mentioned

Email Subject: {subject}

Email Body:
{body[:1000]}

Respond with ONLY a JSON object, no explanation."""

        try:
            response = self.llm.invoke([HumanMessage(content=prompt)])
            result_text = response.content.strip()
            
            # Extract JSON from response
            import json as _json
            # Try to find JSON object in response
            start = result_text.find('{')
            end = result_text.rfind('}') + 1
            if start != -1 and end > start:
                json_str = result_text[start:end]
                event_data = _json.loads(json_str)
                
                # Add metadata
                event_data['source_email_id'] = email.get('id')
                event_data['source_email_subject'] = subject
                event_data['extracted_at'] = datetime.now().isoformat()
                event_data['extraction_method'] = 'llm'
                
                return event_data
        except Exception as e:
            print(f"LLM extraction failed, falling back to simple extraction: {e}")
        
        # Fallback to simple extraction
        event = self.extract_event_simple(email)
        if event:
            event['extraction_method'] = 'pattern_matching'
        return event
    
    def extract_events_from_emails(self, emails: List[Dict[str, Any]], use_llm: bool = True) -> List[Dict[str, Any]]:
        """Extract events from a list of emails.
        
        Args:
            emails: List of email dictionaries
            use_llm: Whether to use LLM for extraction (slower but more accurate)
            
        Returns:
            List of extracted events
        """
        events = []
        
        for email in emails:
            try:
                if use_llm and self.llm:
                    event = self.extract_event_with_llm(email)
                else:
                    event = self.extract_event_simple(email)
                
                if event:
                    events.append(event)
            except Exception as e:
                print(f"Error extracting event from email {email.get('id', 'unknown')}: {e}")
        
        return events
    
    def filter_upcoming_events(self, events: List[Dict[str, Any]], days_ahead: int = 30) -> List[Dict[str, Any]]:
        """Filter events to only include upcoming ones.
        
        Args:
            events: List of event dictionaries
            days_ahead: Number of days to look ahead
            
        Returns:
            Filtered list of upcoming events
        """
        upcoming = []
        cutoff_date = datetime.now() + timedelta(days=days_ahead)
        
        for event in events:
            date_str = event.get('date')
            if not date_str:
                # If no date, include it (user can decide)
                upcoming.append(event)
                continue
            
            try:
                # Try to parse date
                event_date = datetime.strptime(date_str, '%Y-%m-%d')
                if datetime.now() <= event_date <= cutoff_date:
                    upcoming.append(event)
            except ValueError:
                # If can't parse, include it
                upcoming.append(event)
        
        return upcoming


# Example usage and testing
if __name__ == "__main__":
    import os
    
    # Initialize extractor
    extractor = EventExtractor(groq_api_key=os.getenv("GROQ_API_KEY"))
    
    # Sample event emails
    sample_emails = [
        {
            'id': '1',
            'subject': 'Invitation: AI Seminar by Dr. Ahmed Khan',
            'body': {
                'content': '''You are cordially invited to attend a seminar on "The Future of Artificial Intelligence in Pakistan" on Friday, December 25th, 2025 at 2:00 PM in Lecture Hall A.

Speaker: Dr. Ahmed Khan, Professor of Computer Science

Organized by: CS Department

Registration is required. Please confirm your attendance.'''
            },
            'from': {'emailAddress': {'name': 'CS Department', 'address': 'cs.dept@giki.edu.pk'}},
            'receivedDateTime': '2025-12-20T10:00:00Z'
        },
        {
            'id': '2',
            'subject': 'GIKI Annual Music Concert',
            'body': {
                'content': '''Join us for the GIKI Annual Music Concert featuring local and international artists!

Date: January 5, 2026
Time: 7 PM onwards
Venue: Main Auditorium

Tickets available at Student Center. Don't miss out!

Organized by GIKI Music Society'''
            },
            'from': {'emailAddress': {'name': 'Student Affairs', 'address': 'students@giki.edu.pk'}},
            'receivedDateTime': '2025-12-21T14:30:00Z'
        }
    ]
    
    # Extract events
    print("--- Extracting events ---")
    events = extractor.extract_events_from_emails(sample_emails, use_llm=True)
    
    for i, event in enumerate(events):
        print(f"\nEvent {i+1}:")
        print(json.dumps(event, indent=2))
    
    # Filter upcoming events
    print("\n--- Upcoming events (next 30 days) ---")
    upcoming = extractor.filter_upcoming_events(events, days_ahead=30)
    print(f"Found {len(upcoming)} upcoming events")
