# ==================== NEW: RAG SYSTEM ENDPOINTS ====================

@app.route('/api/rag/index', methods=['POST'])
def index_emails_rag():
    """Index current month's emails into RAG system."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.outlook_token:
        return jsonify({'error': 'Outlook not connected'}), 400
    
    # Get emails
    outlook_manager.access_token = user.outlook_token
    emails = outlook_manager.get_emails(max_emails=100, days_back=30)
    
    if not emails:
        return jsonify({'error': 'No emails found'}), 404
    
    # Index emails
    num_indexed = rag_system.index_current_month_emails(emails)
    
    return jsonify({
        'success': True,
        'emails_processed': len(emails),
        'chunks_indexed': num_indexed
    })


@app.route('/api/rag/search', methods=['GET'])
def search_emails_rag():
    """Semantic search over indexed emails."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    query = request.args.get('q', '')
    if not query:
        return jsonify({'error': 'Query required'}), 400
    
    results = rag_system.semantic_search(query, k=5)
    return jsonify({'results': results, 'query': query})


@app.route('/api/rag/query', methods=['POST'])
def query_with_llm_rag():
    """Answer question using RAG + LLM."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    query = data.get('query', '')
    
    if not query:
        return jsonify({'error': 'Query required'}), 400
    
    result = rag_system.query_with_llm(query, k=3)
    return jsonify(result)


# ==================== NEW: EVENT EXTRACTION ENDPOINTS ====================

@app.route('/api/events/extract', methods=['POST'])
def extract_events():
    """Extract events from Outlook emails."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.outlook_token:
        return jsonify({'error': 'Outlook not connected'}), 400
    
    # Get emails
    outlook_manager.access_token = user.outlook_token
    emails = outlook_manager.get_emails(max_emails=50, days_back=60)
    
    if not emails:
        return jsonify({'error': 'No emails found'}), 404
    
    # Extract events
    events = event_extractor.extract_events_from_emails(emails, use_llm=True)
    
    # Save to database
    for event_data in events:
        event = Event(
            title=event_data.get('title', 'Untitled Event'),
            event_type=event_data.get('type', 'other'),
            description=event_data.get('description'),
            date=event_data.get('date'),
            time=event_data.get('time'),
            location=event_data.get('location'),
            organizer=event_data.get('organizer'),
            source_email_id=event_data.get('source_email_id'),
            source_email_subject=event_data.get('source_email_subject'),
            registration_required=event_data.get('registration_required', False),
            extraction_method=event_data.get('extraction_method', 'llm'),
            extracted_at=event_data.get('extracted_at')
        )
        db.session.add(event)
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'events_extracted': len(events),
        'events': events
    })


@app.route('/api/events', methods=['GET'])
def get_events():
    """Get all extracted events."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    # Filter parameters
    event_type = request.args.get('type')
    days_ahead = int(request.args.get('days_ahead', 30))
    
    query = Event.query
    
    if event_type:
        query = query.filter_by(event_type=event_type)
    
    events = query.order_by(Event.created_at.desc()).all()
    
    # Filter upcoming events
    event_dicts = [
        {
            'id': e.id,
            'title': e.title,
            'type': e.event_type,
            'description': e.description,
            'date': e.date,
            'time': e.time,
            'location': e.location,
            'organizer': e.organizer,
            'registration_required': e.registration_required
        }
        for e in events
    ]
    
    upcoming = event_extractor.filter_upcoming_events(event_dicts, days_ahead)
    
    return jsonify({'events': upcoming})


# ==================== NEW: CHAT SYSTEM ENDPOINTS ====================

@app.route('/api/chat/channels', methods=['GET'])
def get_chat_channels():
    """Get all chat channels."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if not chat_system:
        return jsonify({'error': 'Chat system not initialized'}), 500
    
    channels = chat_system.get_channels()
    return jsonify({'channels': channels})


@app.route('/api/chat/messages/<int:channel_id>', methods=['GET'])
def get_channel_messages(channel_id):
    """Get messages from a channel."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if not chat_system:
        return jsonify({'error': 'Chat system not initialized'}), 500
    
    limit = int(request.args.get('limit', 50))
    messages = chat_system.get_channel_messages(channel_id, limit)
    
    return jsonify({'messages': messages})


@app.route('/api/chat/active_users', methods=['GET'])
def get_active_chat_users():
    """Get currently active users."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if not chat_system:
        return jsonify({'error': 'Chat system not initialized'}), 500
    
    users = chat_system.get_active_users()
    return jsonify({'active_users': users})


# ==================== NEW: PAGE ROUTES ====================

@app.route('/events')
def events_page():
    """Events and news page."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    return render_template('events.html', user=user)


@app.route('/chat')
def chat_page():
    """Real-time chat page."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    session['user_name'] = user.name  # For chat system
    return render_template('chat.html', user=user)


@app.route('/navigation')
def navigation_page():
    """Campus navigation page with Google Maps."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    google_maps_key = os.getenv('GOOGLE_MAPS_API_KEY', '')
    
    return render_template('navigation.html', 
                         user=user, 
                         google_maps_api_key=google_maps_key)


# ==================== ENHANCED AGENT with RAG ====================

# Update the existing agent_plan endpoint to use RAG
# Find and replace the current @app.route('/api/agent/plan')
