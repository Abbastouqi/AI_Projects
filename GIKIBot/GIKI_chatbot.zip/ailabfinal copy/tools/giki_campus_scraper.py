#!/usr/bin/env python3
"""GIKI campus scraper: Selenium + OCR + geocoding.

Crawls GIKI buildings and laboratories pages (and sub-links) and builds a
hierarchical JSON structure of buildings, labs, and classrooms with
coordinates suitable for mapping in the campus navigation module.

Requirements (see requirements.txt):
- selenium
- beautifulsoup4
- pytesseract
- pypdf
- pdf2image
- Pillow

You must also have the Tesseract binary installed on your system.
On macOS with Homebrew:
    brew install tesseract

Usage (from project root):
    python tools/giki_campus_scraper.py

This will create `scraped_campus_locations.json` next to this script.
"""

import json
import os
import time
from dataclasses import dataclass, field
from io import BytesIO
from typing import Dict, List, Set, Tuple
from urllib.parse import urljoin, urlparse

import pytesseract
import requests
from PIL import Image
from bs4 import BeautifulSoup
from pdf2image import convert_from_bytes
from pypdf import PdfReader
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


START_URLS = [
    "https://giki.edu.pk/campus-life/buildings/",
    "https://giki.edu.pk/laboratories/",
]

MAX_PAGES = 80
MAX_DEPTH = 2
DOMAIN = "giki.edu.pk"
GIKI_SUFFIX = " in ghulam ishaq khan institute , topo district swabi , kpk"


@dataclass
class PageContent:
    url: str
    title: str = ""
    text: str = ""
    images_text: List[str] = field(default_factory=list)
    pdfs_text: List[str] = field(default_factory=list)


def make_driver() -> webdriver.Chrome:
    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    driver = webdriver.Chrome(options=options)
    return driver


def same_domain(url: str) -> bool:
    parsed = urlparse(url)
    return DOMAIN in (parsed.netloc or "")


def ocr_image_bytes(data: bytes) -> str:
    img = Image.open(BytesIO(data))
    return pytesseract.image_to_string(img)


def extract_pdf_text(resp: requests.Response) -> str:
    parts: List[str] = []

    # Try digital text first
    try:
        reader = PdfReader(BytesIO(resp.content))
        for page in reader.pages:
            parts.append(page.extract_text() or "")
    except Exception:
        pass

    # Fallback: OCR scanned pages
    try:
        images = convert_from_bytes(resp.content)
        for img in images:
            parts.append(pytesseract.image_to_string(img))
    except Exception:
        pass

    return "\n".join(p for p in parts if p)


def scrape_page(driver: webdriver.Chrome, url: str) -> Tuple[PageContent, BeautifulSoup]:
    print(f"[SCRAPE] {url}")
    driver.get(url)
    time.sleep(1.5)

    html = driver.page_source
    soup = BeautifulSoup(html, "html.parser")

    title = (soup.title.string or "").strip() if soup.title else ""
    text_chunks: List[str] = []

    for tag in soup.find_all(["h1", "h2", "h3", "p", "li", "td"]):
        t = tag.get_text(separator=" ", strip=True)
        if t:
            text_chunks.append(t)

    page = PageContent(url=url, title=title, text="\n".join(text_chunks))

    # Images
    for img in soup.find_all("img"):
        src = img.get("src")
        if not src:
            continue
        img_url = urljoin(url, src)
        try:
            r = requests.get(img_url, timeout=10)
            if r.status_code == 200 and r.content:
                page.images_text.append(ocr_image_bytes(r.content))
        except Exception as e:
            print(f"[WARN] Image OCR error {img_url}: {e}")

    # PDFs
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.lower().endswith(".pdf"):
            pdf_url = urljoin(url, href)
            try:
                r = requests.get(pdf_url, timeout=20)
                if r.status_code == 200:
                    page.pdfs_text.append(extract_pdf_text(r))
            except Exception as e:
                print(f"[WARN] PDF parse error {pdf_url}: {e}")

    return page, soup


def crawl_site() -> Dict[str, PageContent]:
    driver = make_driver()
    visited: Set[str] = set()
    queue: List[Tuple[str, int]] = [(u, 0) for u in START_URLS]
    pages: Dict[str, PageContent] = {}

    try:
        while queue and len(visited) < MAX_PAGES:
            url, depth = queue.pop(0)
            if url in visited or depth > MAX_DEPTH or not same_domain(url):
                continue

            visited.add(url)
            try:
                page, soup = scrape_page(driver, url)
                pages[url] = page
            except Exception as e:
                print(f"[ERROR] scraping {url}: {e}")
                continue

            for a in soup.find_all("a", href=True):
                link = urljoin(url, a["href"])
                if same_domain(link) and link not in visited:
                    queue.append((link, depth + 1))
    finally:
        driver.quit()

    print(f"[INFO] Crawled {len(pages)} pages")
    return pages


def geocode_location(name: str, building: str | None = None) -> Tuple[float | None, float | None]:
    query = name
    if building and building.lower() not in name.lower():
        query = f"{name} {building}"
    full_query = f"{query}{GIKI_SUFFIX}"
    print(f"[GEOCODE] {full_query}")

    try:
        resp = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={
                "q": full_query,
                "format": "json",
                "limit": 1,
            },
            headers={"User-Agent": "giki-student-services-app/1.0 (scraper)"},
            timeout=8,
        )
        if resp.status_code != 200:
            return None, None
        data = resp.json()
        if not data:
            return None, None
        return float(data[0]["lat"]), float(data[0]["lon"])
    except Exception as e:
        print(f"[WARN] Geocode failed for {name}: {e}")
        return None, None


def build_hierarchy(pages: Dict[str, PageContent]) -> Dict:
    """Heuristic parser to build a GIKI hierarchy.

    Output structure (high level):

        {
          "giki": {
            "name": "...",
            "faculties": {
              "Faculty of ...": {
                "name": "Faculty of ...",
                "labs": [...],
                "classrooms": [...],
              },
              ...
            },
            "buildings": {
              "Academic Block": {"name": ..., "labs": [...], "classrooms": [...]},
              ...
            }
          }
        }

    This keeps the previous buildings structure but also introduces a
    faculty-level grouping so the app can later map labs/classrooms to
    their relevant faculty/department.
    """
    hierarchy: Dict = {
        "giki": {
            "name": "Ghulam Ishaq Khan Institute of Engineering Sciences and Technology",
            "faculties": {},
            "buildings": {},
        }
    }

    building_keywords = ["block", "building", "center", "centre", "department"]
    lab_keywords = ["lab", "laboratory"]
    lecture_keywords = ["lecture hall", "classroom"]
    faculty_keywords = ["faculty of", "department of"]

    current_faculty: str | None = None
    current_building: str | None = None

    for page in pages.values():
        all_text = "\n".join([page.title, page.text] + page.images_text + page.pdfs_text).split("\n")
        for line in all_text:
            l = line.strip()
            if not l:
                continue
            lower = l.lower()

            # Detect faculty / department headings
            if any(k in lower for k in faculty_keywords):
                current_faculty = l
                if current_faculty not in hierarchy["giki"]["faculties"]:
                    hierarchy["giki"]["faculties"][current_faculty] = {
                        "name": current_faculty,
                        "labs": [],
                        "classrooms": [],
                    }
                # Do not continue; same line might also contain a building keyword

            # Detect buildings (including department buildings)
            if any(k in lower for k in building_keywords):
                bname = l
                bkey = bname
                current_building = bkey
                if bkey not in hierarchy["giki"]["buildings"]:
                    lat, lon = geocode_location(bname)
                    hierarchy["giki"]["buildings"][bkey] = {
                        "name": bname,
                        "lat": lat,
                        "lon": lon,
                        "labs": [],
                        "classrooms": [],
                    }
                continue

            # Detect labs
            if any(k in lower for k in lab_keywords):
                lname = l
                # Attach to a specific building if we have one, else generic
                bkey = current_building or "Labs / Laboratories"
                if bkey not in hierarchy["giki"]["buildings"]:
                    lat, lon = geocode_location("laboratories building")
                    hierarchy["giki"]["buildings"][bkey] = {
                        "name": bkey,
                        "lat": lat,
                        "lon": lon,
                        "labs": [],
                        "classrooms": [],
                    }
                lat, lon = geocode_location(lname, building=current_building or None)
                lab_entry = {
                    "name": lname,
                    "lat": lat,
                    "lon": lon,
                }
                if current_faculty:
                    lab_entry["faculty"] = current_faculty
                    hierarchy["giki"]["faculties"].setdefault(
                        current_faculty,
                        {"name": current_faculty, "labs": [], "classrooms": []},
                    )["labs"].append(lab_entry)
                hierarchy["giki"]["buildings"][bkey]["labs"].append(lab_entry)
                continue

            # Detect lecture halls / classrooms
            if any(k in lower for k in lecture_keywords):
                cname = l
                bkey = current_building or "Academic Block / Lecture Halls"
                if bkey not in hierarchy["giki"]["buildings"]:
                    lat, lon = geocode_location("academic block lecture halls")
                    hierarchy["giki"]["buildings"][bkey] = {
                        "name": bkey,
                        "lat": lat,
                        "lon": lon,
                        "labs": [],
                        "classrooms": [],
                    }
                lat, lon = geocode_location(cname, building=current_building or "Academic Block")
                room_entry = {
                    "name": cname,
                    "lat": lat,
                    "lon": lon,
                }
                if current_faculty:
                    room_entry["faculty"] = current_faculty
                    hierarchy["giki"]["faculties"].setdefault(
                        current_faculty,
                        {"name": current_faculty, "labs": [], "classrooms": []},
                    )["classrooms"].append(room_entry)
                hierarchy["giki"]["buildings"][bkey]["classrooms"].append(room_entry)

    return hierarchy


def main() -> None:
    pages = crawl_site()
    hierarchy = build_hierarchy(pages)

    out_path = os.path.join(os.path.dirname(__file__), "scraped_campus_locations.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(hierarchy, f, ensure_ascii=False, indent=2)

    print(f"[DONE] Saved hierarchy to {out_path}")


if __name__ == "__main__":
    main()
