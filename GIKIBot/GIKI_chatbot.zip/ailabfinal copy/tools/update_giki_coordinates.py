#!/usr/bin/env python3
"""
Script to update GIKI coordinates in the main app.
Run this after you've collected accurate coordinates.
"""

import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def update_coordinates():
    """Update the geocode_giki_location function with new coordinates"""
    
    # Read the current app.py
    with open('../app.py', 'r') as f:
        content = f.read()
    
    # Your new accurate coordinates go here
    new_coordinates = {
        "giki_main_gate": (33.7840, 72.3740),
        "academic_block": (33.7841, 72.3743),
        "cs_department": (33.7840, 72.3742),
        "ee_department": (33.7842, 72.3744),
        "central_library": (33.7842, 72.3744),
        "student_center": (33.7843, 72.3745),
        # Add more coordinates as you collect them
    }
    
    print("Current coordinates in app.py will be updated with:")
    for name, coords in new_coordinates.items():
        print(f"  {name}: {coords}")
    
    print("\nTo update coordinates:")
    print("1. Get accurate coordinates from Google Maps")
    print("2. Update the new_coordinates dictionary in this file")
    print("3. Run: python3 tools/update_giki_coordinates.py")
    print("4. Restart the Flask app")

if __name__ == "__main__":
    update_coordinates()
