#!/usr/bin/env python3
"""
Tool to help you get accurate coordinates for GIKI locations.
This provides instructions and a format for organizing the coordinates.
"""

# Instructions for getting accurate coordinates from Google Maps:
"""
1. Go to https://maps.google.com
2. Search for "Ghulam Ishaq Khan Institute of Engineering Sciences and Technology"
3. Zoom in to see the campus buildings
4. For each location you want to mark:
   - Right-click on the exact spot
   - The coordinates will appear in the popup
   - Copy the coordinates (e.g., 33.7841, 72.3743)
5. Record them in the format below

Suggested locations to mark:
- Main Gate/Entrance
- Academic Block (center)
- CS Department building
- EE Department building  
- ME Department building
- CE Department building
- Library building
- Student Center/Mess
- Hostels (main ones)
- Sports complex
- Mosque
- Admin block
- Labs (specific ones)
- Lecture halls (main ones)
"""

# Format for organizing coordinates:
LOCATION_COORDINATES = {
    # Main campus areas
    "giki_main_gate": (33.7840, 72.3740),
    "academic_block": (33.7841, 72.3743),
    
    # Department buildings
    "cs_department": (33.7840, 72.3742),
    "ee_department": (33.7842, 72.3744),
    "me_department": (33.7843, 72.3745),
    "ce_department": (33.7844, 72.3746),
    
    # Facilities
    "central_library": (33.7842, 72.3744),
    "student_center": (33.7843, 72.3745),
    "main_mess": (33.7843, 72.3745),
    "mosque": (33.7845, 72.3747),
    
    # Hostels
    "hostel_a": (33.7850, 72.3750),
    "hostel_b": (33.7851, 72.3751),
    "hostel_c": (33.7852, 72.3752),
    
    # Labs
    "computer_lab_1": (33.7840, 72.3742),
    "computer_lab_2": (33.7840, 72.3742),
    "electronics_lab": (33.7842, 72.3744),
    "mechanics_lab": (33.7843, 72.3745),
    
    # Lecture halls
    "lecture_hall_a": (33.7841, 72.3743),
    "lecture_hall_b": (33.7841, 72.3743),
    "lecture_hall_c": (33.7841, 72.3743),
}

# Once you have the coordinates, you can update the app.py file like this:
UPDATE_CODE = '''
def geocode_giki_location(name: str) -> tuple[Optional[float], Optional[float]]:
    """Geocode a location constrained to GIKI using known coordinates or Nominatim."""
    
    # Known accurate coordinates for GIKI locations (UPDATE THESE)
    known_locations = {
        "giki_main_gate": (33.7840, 72.3740),
        "academic_block": (33.7841, 72.3743),
        "cs_department": (33.7840, 72.3742),
        # ... add all your coordinates here
    }
    
    # ... rest of the function remains the same
'''

if __name__ == "__main__":
    print("=== GIKI Coordinate Collection Tool ===")
    print("\n1. Open Google Maps: https://maps.google.com")
    print("2. Search for: Ghulam Ishaq Khan Institute")
    print("3. Right-click on each location to get coordinates")
    print("4. Update the LOCATION_COORDINATES dictionary above")
    print("\nAfter collecting coordinates, run:")
    print("python3 tools/update_giki_coordinates.py")
