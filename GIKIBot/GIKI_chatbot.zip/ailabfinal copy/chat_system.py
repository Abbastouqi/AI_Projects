#!/usr/bin/env python3
"""
Real-time Chat System for GIKI Student Services Platform

Handles WebSocket-based real-time messaging between students, faculty, and administration.
"""

import os
import json
from typing import List, Dict, Optional, Any
from datetime import datetime
from pathlib import Path

from flask_socketio import SocketIO, emit, join_room, leave_room, rooms
from flask import request, session


class ChatSystem:
    """Real-time chat system with WebSocket support."""
    
    # Channel types
    CHANNEL_TYPES = {
        'student-student': 'Student to Student',
        'student-faculty': 'Student to Faculty',
        'student-admin': 'Student to Administration',
        'faculty-admin': 'Faculty to Administration',
        'general': 'General Discussion',
        'announcements': 'Announcements (Admin Only)'
    }
    
    def __init__(self, socketio: SocketIO, db):
        """Initialize chat system.
        
        Args:
            socketio: Flask-SocketIO instance
            db: SQLAlchemy database instance
        """
        self.socketio = socketio
        self.db = db
        self.active_users = {}  # {user_id: {socket_id, name, status}}
        
        # Register Socket.IO event handlers
        self._register_handlers()
    
    def _register_handlers(self):
        """Register WebSocket event handlers."""
        
        @self.socketio.on('connect')
        def handle_connect():
            """Handle user connection."""
            user_id = session.get('user_id')
            if not user_id:
                return False  # Reject connection if not authenticated
            
            # Store user info
            self.active_users[user_id] = {
                'socket_id': request.sid,
                'name': session.get('user_name', 'Unknown'),
                'status': 'online',
                'connected_at': datetime.now().isoformat()
            }
            
            # Emit user status to all clients
            emit('user_status', {
                'user_id': user_id,
                'status': 'online',
                'name': self.active_users[user_id]['name']
            }, broadcast=True)
            
            print(f"User {user_id} connected")
        
        @self.socketio.on('disconnect')
        def handle_disconnect():
            """Handle user disconnection."""
            user_id = session.get('user_id')
            if user_id and user_id in self.active_users:
                # Update status
                self.active_users[user_id]['status'] = 'offline'
                
                # Emit status change
                emit('user_status', {
                    'user_id': user_id,
                    'status': 'offline',
                    'name': self.active_users[user_id]['name']
                }, broadcast=True)
                
                # Remove from active users after a delay (they might reconnect)
                # In production, use a background task for this
                del self.active_users[user_id]
                
                print(f"User {user_id} disconnected")
        
        @self.socketio.on('join_channel')
        def handle_join_channel(data):
            """Handle user joining a chat channel."""
            channel_id = data.get('channel_id')
            user_id = session.get('user_id')
            
            if not channel_id or not user_id:
                return
            
            # Join the room
            join_room(str(channel_id))
            
            # Notify others in the channel
            emit('user_joined', {
                'user_id': user_id,
                'user_name': self.active_users.get(user_id, {}).get('name', 'Unknown'),
                'channel_id': channel_id
            }, room=str(channel_id))
            
            print(f"User {user_id} joined channel {channel_id}")
        
        @self.socketio.on('leave_channel')
        def handle_leave_channel(data):
            """Handle user leaving a chat channel."""
            channel_id = data.get('channel_id')
            user_id = session.get('user_id')
            
            if not channel_id or not user_id:
                return
            
            # Leave the room
            leave_room(str(channel_id))
            
            # Notify others in the channel
            emit('user_left', {
                'user_id': user_id,
                'user_name': self.active_users.get(user_id, {}).get('name', 'Unknown'),
                'channel_id': channel_id
            }, room=str(channel_id))
            
            print(f"User {user_id} left channel {channel_id}")
        
        @self.socketio.on('send_message')
        def handle_send_message(data):
            """Handle sending a chat message."""
            from app import ChatMessage  # Import here to avoid circular import
            
            user_id = session.get('user_id')
            if not user_id:
                return
            
            channel_id = data.get('channel_id')
            content = data.get('content', '').strip()
            message_type = data.get('type', 'text')  # text, image, file
            attachment_url = data.get('attachment_url')
            
            if not channel_id or not content:
                emit('error', {'message': 'Invalid message data'})
                return
            
            # Save message to database
            try:
                message = ChatMessage(
                    channel_id=channel_id,
                    user_id=user_id,
                    content=content,
                    message_type=message_type,
                    attachment_url=attachment_url
                )
                self.db.session.add(message)
                self.db.session.commit()
                
                # Prepare message data for broadcast
                message_data = {
                    'id': message.id,
                    'channel_id': channel_id,
                    'user_id': user_id,
                    'user_name': self.active_users.get(user_id, {}).get('name', 'Unknown'),
                    'content': content,
                    'type': message_type,
                    'attachment_url': attachment_url,
                    'created_at': message.created_at.isoformat(),
                    'is_edited': False
                }
                
                # Broadcast message to channel
                emit('new_message', message_data, room=str(channel_id))
                
                print(f"Message {message.id} sent to channel {channel_id}")
                
            except Exception as e:
                print(f"Error saving message: {e}")
                emit('error', {'message': 'Failed to send message'})
        
        @self.socketio.on('typing')
        def handle_typing(data):
            """Handle typing indicator."""
            channel_id = data.get('channel_id')
            user_id = session.get('user_id')
            is_typing = data.get('is_typing', False)
            
            if not channel_id or not user_id:
                return
            
            # Broadcast typing status to channel (except sender)
            emit('user_typing', {
                'user_id': user_id,
                'user_name': self.active_users.get(user_id, {}).get('name', 'Unknown'),
                'channel_id': channel_id,
                'is_typing': is_typing
            }, room=str(channel_id), include_self=False)
        
        @self.socketio.on('mark_read')
        def handle_mark_read(data):
            """Handle marking messages as read."""
            from app import ChatMessage  # Import here to avoid circular import
            
            message_ids = data.get('message_ids', [])
            user_id = session.get('user_id')
            
            if not message_ids or not user_id:
                return
            
            # In a full implementation, you'd have a read_receipts table
            # For now, just acknowledge
            emit('messages_read', {
                'message_ids': message_ids,
                'read_by': user_id
            }, broadcast=True)
    
    def get_active_users(self) -> List[Dict[str, Any]]:
        """Get list of currently active users.
        
        Returns:
            List of active user dictionaries
        """
        return [
            {
                'user_id': user_id,
                'name': info['name'],
                'status': info['status'],
                'connected_at': info.get('connected_at')
            }
            for user_id, info in self.active_users.items()
            if info['status'] == 'online'
        ]
    
    def get_channel_messages(self, channel_id: int, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent messages from a channel.
        
        Args:
            channel_id: Channel ID
            limit: Maximum number of messages to return
            
        Returns:
            List of message dictionaries
        """
        from app import ChatMessage, User  # Import here to avoid circular import
        
        messages = (
            self.db.session.query(ChatMessage)
            .filter_by(channel_id=channel_id)
            .order_by(ChatMessage.created_at.desc())
            .limit(limit)
            .all()
        )
        
        # Reverse to get chronological order
        messages.reverse()
        
        result = []
        for msg in messages:
            user = self.db.session.get(User, msg.user_id)
            result.append({
                'id': msg.id,
                'channel_id': msg.channel_id,
                'user_id': msg.user_id,
                'user_name': user.name if user else 'Unknown',
                'content': msg.content,
                'type': msg.message_type,
                'attachment_url': msg.attachment_url,
                'created_at': msg.created_at.isoformat(),
                'is_edited': msg.is_edited
            })
        
        return result
    
    def create_channel(self, name: str, channel_type: str, description: str = None) -> Optional[int]:
        """Create a new chat channel.
        
        Args:
            name: Channel name
            channel_type: Channel type (from CHANNEL_TYPES)
            description: Optional description
            
        Returns:
            Channel ID or None if failed
        """
        from app import ChatChannel  # Import here to avoid circular import
        
        if channel_type not in self.CHANNEL_TYPES:
            print(f"Invalid channel type: {channel_type}")
            return None
        
        try:
            channel = ChatChannel(
                name=name,
                channel_type=channel_type,
                description=description or self.CHANNEL_TYPES[channel_type]
            )
            self.db.session.add(channel)
            self.db.session.commit()
            
            print(f"Created channel {channel.id}: {name}")
            return channel.id
            
        except Exception as e:
            print(f"Error creating channel: {e}")
            self.db.session.rollback()
            return None
    
    def get_channels(self) -> List[Dict[str, Any]]:
        """Get all available chat channels.
        
        Returns:
            List of channel dictionaries
        """
        from app import ChatChannel  # Import here to avoid circular import
        
        channels = self.db.session.query(ChatChannel).filter_by(is_active=True).all()
        
        return [
            {
                'id': ch.id,
                'name': ch.name,
                'type': ch.channel_type,
                'description': ch.description,
                'created_at': ch.created_at.isoformat()
            }
            for ch in channels
        ]


# Utility function to initialize default channels
def initialize_default_channels(chat_system: ChatSystem):
    """Create default chat channels if they don't exist.
    
    Args:
        chat_system: ChatSystem instance
    """
    from app import ChatChannel  # Import here to avoid circular import
    
    # Check if channels already exist
    if ChatChannel.query.count() > 0:
        print("Chat channels already initialized")
        return
    
    # Create default channels
    default_channels = [
        ('Student Discussion', 'student-student', 'General discussion area for students'),
        ('Ask Faculty', 'student-faculty', 'Ask questions to faculty members'),
        ('Student Services', 'student-admin', 'Contact administration for services'),
        ('Faculty Lounge', 'faculty-admin', 'Faculty and admin communication'),
        ('Announcements', 'announcements', 'Official announcements (read-only for students)')
    ]
    
    for name, channel_type, description in default_channels:
        chat_system.create_channel(name, channel_type, description)
    
    print(f"Initialized {len(default_channels)} default chat channels")


# Example usage
if __name__ == "__main__":
    print("Chat system module - import this in your Flask app")
    print("Available channel types:")
    for key, value in ChatSystem.CHANNEL_TYPES.items():
        print(f"  {key}: {value}")
