#!/usr/bin/env python3
"""
GIKI Student Services Platform
A comprehensive student services platform with Outlook integration, complaint system,
interactive navigation, food ordering, and more.
"""

import os
import json
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any
import msal
import requests
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import secrets
from functools import wraps

# AI/ML Imports
from langchain_groq import ChatGroq
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.chains import RetrievalQA
from langchain.docstore.document import Document
from langchain.prompts import PromptTemplate
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Initialize Flask App
app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///giki_services.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Microsoft Graph API Configuration
AZURE_CLIENT_ID = os.getenv('AZURE_CLIENT_ID', '4fcd1516-dcd5-4e11-aa97-07f230f30055')
GROQ_API_KEY = os.getenv('GROQ_API_KEY', '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')
AUTHORITY = "https://login.microsoftonline.com/common"
SCOPES = [
    "https://graph.microsoft.com/Mail.Read",
    "https://graph.microsoft.com/Mail.ReadWrite", 
    "https://graph.microsoft.com/Mail.Send",
    "https://graph.microsoft.com/Mail.Create",
    "https://graph.microsoft.com/User.Read",
    "https://graph.microsoft.com/User.ReadWrite",
    "https://graph.microsoft.com/Calendars.Read",
    "https://graph.microsoft.com/Calendars.ReadWrite",
    "https://graph.microsoft.com/Contacts.Read",
    "https://graph.microsoft.com/Contacts.ReadWrite",
    "https://graph.microsoft.com/Files.Read",
    "https://graph.microsoft.com/Files.ReadWrite",
    "https://graph.microsoft.com/Sites.Read",
    "https://graph.microsoft.com/Sites.ReadWrite"
]

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    roll_number = db.Column(db.String(20), unique=True, nullable=False)
    hostel = db.Column(db.String(50))
    room_number = db.Column(db.String(20))
    phone = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    outlook_token = db.Column(db.Text)  # Store Outlook access token

class Complaint(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    subcategory = db.Column(db.String(100))
    description = db.Column(db.Text, nullable=False)
    urgency = db.Column(db.String(20), default='medium')
    status = db.Column(db.String(20), default='pending')
    assigned_to = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime)
    user = db.relationship('User', backref=db.backref('complaints', lazy=True))

class DepartmentContact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    designation = db.Column(db.String(100))
    email = db.Column(db.String(120))
    phone = db.Column(db.String(20))
    office_location = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)

class CampusLocation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50))  # classroom, lab, hall, office, etc.
    building = db.Column(db.String(50))
    floor = db.Column(db.String(10))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    description = db.Column(db.Text)
    keywords = db.Column(db.Text)  # JSON array of search keywords

class Restaurant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50))  # mess, cafe, tuc, etc.
    location = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, default=True)
    menu_items = db.relationship('MenuItem', backref='restaurant', lazy=True)

class MenuItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurant.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50))
    is_available = db.Column(db.Boolean, default=True)
    preparation_time = db.Column(db.Integer)  # minutes

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurant.id'), nullable=False)
    items = db.Column(db.Text)  # JSON of order items
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')
    delivery_location = db.Column(db.String(100))
    special_instructions = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    estimated_delivery = db.Column(db.DateTime)
    user = db.relationship('User', backref=db.backref('orders', lazy=True))
    restaurant = db.relationship('Restaurant', backref=db.backref('orders', lazy=True))

# Enhanced Outlook Manager
class EnhancedOutlookManager:
    def __init__(self, client_id: str, scopes: List[str]):
        self.client_id = client_id
        self.scopes = scopes
        self.access_token = None
        self.refresh_token = None
        self.app = None

    def authenticate(self, token_cache=None):
        """Authenticate using device code flow"""
        self.app = msal.PublicClientApplication(
            self.client_id,
            authority=AUTHORITY,
            token_cache=token_cache
        )

        flow = self.app.initiate_device_flow(scopes=self.scopes)
        if "user_code" not in flow:
            raise ValueError("Failed to create device flow")

        return flow

    def acquire_token_by_device_flow(self, flow):
        """Complete device flow authentication"""
        result = self.app.acquire_token_by_device_flow(flow)
        if "access_token" in result:
            self.access_token = result["access_token"]
            self.refresh_token = result.get("refresh_token")
            return True
        return False

    def get_user_info(self) -> Dict:
        """Get current user information"""
        if not self.access_token:
            return None

        headers = {"Authorization": f"Bearer {self.access_token}"}
        response = requests.get("https://graph.microsoft.com/v1.0/me", headers=headers)
        
        if response.status_code == 200:
            return response.json()
        return None

    def get_emails(self, max_emails: int = 100, days_back: int = 30) -> List[Dict]:
        """Fetch emails with enhanced filtering"""
        if not self.access_token:
            return []

        headers = {"Authorization": f"Bearer {self.access_token}"}
        start_date = (datetime.now() - timedelta(days=days_back)).isoformat() + "Z"

        url = "https://graph.microsoft.com/v1.0/me/messages"
        params = {
            "$top": max_emails,
            "$orderby": "receivedDateTime DESC",
            "$filter": f"receivedDateTime ge {start_date}",
            "$select": "subject,from,receivedDateTime,bodyPreview,body,isRead,hasAttachments,importance,cc,bcc"
        }

        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            return response.json().get("value", [])
        return []

    def send_email(self, to_recipients: List[str], subject: str, body: str, cc_recipients: List[str] = None) -> bool:
        """Send email via Graph API"""
        if not self.access_token:
            return False

        headers = {"Authorization": f"Bearer {self.access_token}", "Content-Type": "application/json"}
        
        email_data = {
            "message": {
                "subject": subject,
                "body": {"contentType": "Text", "content": body},
                "toRecipients": [{"emailAddress": {"address": email}} for email in to_recipients]
            }
        }
        
        if cc_recipients:
            email_data["message"]["ccRecipients"] = [{"emailAddress": {"address": email}} for email in cc_recipients]

        response = requests.post(
            "https://graph.microsoft.com/v1.0/me/sendMail",
            headers=headers,
            json=email_data
        )
        
        return response.status_code == 202

    def get_contacts(self) -> List[Dict]:
        """Get user contacts"""
        if not self.access_token:
            return []

        headers = {"Authorization": f"Bearer {self.access_token}"}
        response = requests.get("https://graph.microsoft.com/v1.0/me/contacts", headers=headers)
        
        if response.status_code == 200:
            return response.json().get("value", [])
        return []

    def get_calendar_events(self, days_ahead: int = 7) -> List[Dict]:
        """Get calendar events"""
        if not self.access_token:
            return []

        headers = {"Authorization": f"Bearer {self.access_token}"}
        end_date = (datetime.now() + timedelta(days=days_ahead)).isoformat() + "Z"
        
        url = "https://graph.microsoft.com/v1.0/me/events"
        params = {
            "$orderby": "start/dateTime ASC",
            "$filter": f"start/dateTime le {end_date}"
        }

        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            return response.json().get("value", [])
        return []

# Complaint Processing System
class ComplaintProcessor:
    def __init__(self, groq_api_key: str):
        self.llm = ChatGroq(
            groq_api_key=groq_api_key,
            model_name="llama-3.1-70b-versatile",
            temperature=0.1
        )
        
        # Initialize TF-IDF for categorization
        self.vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
        self.category_keywords = {
            'hostel': ['room', 'hostel', 'mess', 'food', 'water', 'electricity', 'plumbing', 'furniture'],
            'academic': ['course', 'teacher', 'exam', 'grade', 'assignment', 'lecture', 'class'],
            'internet': ['wifi', 'internet', 'network', 'connection', 'slow', 'speed'],
            'maintenance': ['repair', 'broken', 'damaged', 'maintenance', 'cleaning'],
            'administrative': ['fee', 'registration', 'document', 'certificate', 'office'],
            'security': ['security', 'safety', 'gate', 'entry', 'card', 'access']
        }

    def categorize_complaint(self, description: str) -> Dict:
        """Categorize complaint using TF-IDF and keyword matching"""
        # Preprocess
        text = description.lower()
        
        # Keyword matching
        category_scores = {}
        for category, keywords in self.category_keywords.items():
            score = sum(1 for keyword in keywords if keyword in text)
            category_scores[category] = score
        
        # Get best category
        best_category = max(category_scores, key=category_scores.get)
        confidence = category_scores[best_category] / len(self.category_keywords[best_category])
        
        # Use LLM for better categorization if confidence is low
        if confidence < 0.3:
            prompt = f"""
            Categorize this student complaint into one of these categories: 
            hostel, academic, internet, maintenance, administrative, security
            
            Complaint: {description}
            
            Respond with JSON format: {{"category": "category_name", "subcategory": "specific_issue", "urgency": "low/medium/high"}}
            """
            
            try:
                response = self.llm.invoke([HumanMessage(content=prompt)])
                import re
                json_match = re.search(r'\{.*\}', response.content, re.DOTALL)
                if json_match:
                    llm_result = json.loads(json_match.group())
                    best_category = llm_result.get('category', best_category)
                    confidence = 0.8
            except:
                pass
        
        return {
            'category': best_category,
            'confidence': confidence,
            'urgency': self._assess_urgency(description)
        }

    def _assess_urgency(self, description: str) -> str:
        """Assess complaint urgency"""
        urgent_keywords = ['urgent', 'emergency', 'immediately', 'critical', 'broken', 'no water', 'no electricity']
        text = description.lower()
        
        if any(keyword in text for keyword in urgent_keywords):
            return 'high'
        elif any(keyword in text for keyword in ['please', 'soon', 'asap']):
            return 'medium'
        else:
            return 'low'

    def find_relevant_contacts(self, category: str, subcategory: str = None) -> List[Dict]:
        """Find relevant department contacts for complaint"""
        contacts = DepartmentContact.query.filter_by(is_active=True).all()
        
        # Simple mapping - in production, this would be more sophisticated
        category_mapping = {
            'hostel': ['Hostel Warden', 'Mess Manager', 'Maintenance'],
            'academic': ['Academic Affairs', 'Department Head', 'Course Coordinator'],
            'internet': ['IT Department', 'Network Administrator'],
            'maintenance': ['Maintenance Department', 'Engineering Staff'],
            'administrative': ['Admin Office', 'Student Affairs', 'Registration'],
            'security': ['Security Office', 'Campus Security']
        }
        
        relevant_titles = category_mapping.get(category, ['Admin Office'])
        relevant_contacts = []
        
        for contact in contacts:
            if any(title.lower() in contact.designation.lower() for title in relevant_titles):
                relevant_contacts.append({
                    'name': contact.name,
                    'department': contact.department,
                    'designation': contact.designation,
                    'email': contact.email,
                    'phone': contact.phone,
                    'office_location': contact.office_location
                })
        
        return relevant_contacts

# Campus Navigation System
class CampusNavigator:
    def __init__(self):
        self.locations = CampusLocation.query.all()
        
    def search_location(self, query: str) -> List[Dict]:
        """Search for campus locations using natural language"""
        query_lower = query.lower()
        
        # Keyword extraction and matching
        results = []
        for location in self.locations:
            score = 0
            
            # Name matching
            if any(word in location.name.lower() for word in query_lower.split()):
                score += 3
            
            # Category matching
            if location.category and location.category.lower() in query_lower:
                score += 2
            
            # Keywords matching
            if location.keywords:
                keywords = json.loads(location.keywords)
                if any(keyword.lower() in query_lower for keyword in keywords):
                    score += 2
            
            # Building matching
            if location.building and any(word in location.building.lower() for word in query_lower.split()):
                score += 1
            
            if score > 0:
                results.append({
                    'id': location.id,
                    'name': location.name,
                    'category': location.category,
                    'building': location.building,
                    'floor': location.floor,
                    'latitude': location.latitude,
                    'longitude': location.longitude,
                    'description': location.description,
                    'score': score
                })
        
        # Sort by score
        results.sort(key=lambda x: x['score'], reverse=True)
        return results[:5]  # Return top 5 results

    def get_directions(self, from_lat: float, from_lng: float, to_lat: float, to_lng: float) -> Dict:
        """Get directions between two points"""
        # Simple distance calculation (in production, use proper routing API)
        distance = self._calculate_distance(from_lat, from_lng, to_lat, to_lng)
        
        # Estimate walking time (assuming 5 km/h walking speed)
        walking_time = int((distance / 5) * 60)  # minutes
        
        return {
            'distance': distance,
            'walking_time': walking_time,
            'mode': 'walking',
            'steps': [
                {
                    'instruction': f'Head towards {self._get_direction(from_lat, from_lng, to_lat, to_lng)}',
                    'distance': distance,
                    'duration': walking_time
                }
            ]
        }

    def _calculate_distance(self, lat1: float, lng1: float, lat2: float, lng2: float) -> float:
        """Calculate distance between two coordinates"""
        from math import radians, cos, sin, asin, sqrt
        
        lat1, lng1, lat2, lng2 = map(radians, [lat1, lng1, lat2, lng2])
        dlat = lat2 - lat1
        dlng = lng2 - lng1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlng/2)**2
        c = 2 * asin(sqrt(a))
        km = 6371 * c
        return km

    def _get_direction(self, lat1: float, lng1: float, lat2: float, lng2: float) -> str:
        """Get cardinal direction between two points"""
        lat_diff = lat2 - lat1
        lng_diff = lng2 - lng1
        
        if abs(lat_diff) > abs(lng_diff):
            return 'north' if lat_diff > 0 else 'south'
        else:
            return 'east' if lng_diff > 0 else 'west'

# Food Ordering System
class FoodOrderingSystem:
    def __init__(self):
        self.restaurants = Restaurant.query.filter_by(is_active=True).all()
    
    def get_restaurants(self) -> List[Dict]:
        """Get all active restaurants"""
        return [
            {
                'id': r.id,
                'name': r.name,
                'category': r.category,
                'location': r.location,
                'phone': r.phone
            }
            for r in self.restaurants
        ]
    
    def get_menu(self, restaurant_id: int) -> List[Dict]:
        """Get menu for a specific restaurant"""
        restaurant = Restaurant.query.get(restaurant_id)
        if not restaurant:
            return []
        
        return [
            {
                'id': item.id,
                'name': item.name,
                'description': item.description,
                'price': item.price,
                'category': item.category,
                'is_available': item.is_available,
                'preparation_time': item.preparation_time
            }
            for item in restaurant.menu_items
            if item.is_available
        ]
    
    def create_order(self, user_id: int, restaurant_id: int, items: List[Dict], 
                    delivery_location: str = None, special_instructions: str = None) -> Dict:
        """Create a new order"""
        restaurant = Restaurant.query.get(restaurant_id)
        if not restaurant:
            return {'error': 'Restaurant not found'}
        
        # Calculate total and validate items
        total = 0
        valid_items = []
        
        for item_data in items:
            menu_item = MenuItem.query.get(item_data['id'])
            if menu_item and menu_item.is_available:
                total += menu_item.price * item_data['quantity']
                valid_items.append({
                    'id': menu_item.id,
                    'name': menu_item.name,
                    'price': menu_item.price,
                    'quantity': item_data['quantity']
                })
        
        if not valid_items:
            return {'error': 'No valid items in order'}
        
        # Estimate delivery time
        max_prep_time = max(MenuItem.query.get(item['id']).preparation_time or 15 for item in valid_items)
        estimated_delivery = datetime.now() + timedelta(minutes=max_prep_time + 10)  # 10 mins for delivery
        
        # Create order
        order = Order(
            user_id=user_id,
            restaurant_id=restaurant_id,
            items=json.dumps(valid_items),
            total_amount=total,
            delivery_location=delivery_location,
            special_instructions=special_instructions,
            estimated_delivery=estimated_delivery
        )
        
        db.session.add(order)
        db.session.commit()
        
        return {
            'order_id': order.id,
            'total': total,
            'estimated_delivery': estimated_delivery.isoformat(),
            'items': valid_items
        }

# Initialize systems
outlook_manager = EnhancedOutlookManager(AZURE_CLIENT_ID, SCOPES)
complaint_processor = ComplaintProcessor(GROQ_API_KEY)
campus_navigator = CampusNavigator()
food_system = FoodOrderingSystem()

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login():
    """Initiate Outlook login"""
    try:
        flow = outlook_manager.authenticate()
        session['device_flow'] = flow
        return render_template('login.html', flow=flow)
    except Exception as e:
        flash(f'Login error: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/auth/callback')
def auth_callback():
    """Handle authentication callback"""
    flow = session.get('device_flow')
    if not flow:
        flash('Authentication session expired', 'error')
        return redirect(url_for('index'))
    
    if outlook_manager.acquire_token_by_device_flow(flow):
        user_info = outlook_manager.get_user_info()
        if user_info:
            # Create or update user
            user = User.query.filter_by(email=user_info['mail'] or user_info['userPrincipalName']).first()
            if not user:
                # Extract roll number from email (assuming format: u2022074@giki.edu.pk)
                email = user_info['mail'] or user_info['userPrincipalName']
                roll_number = email.split('@')[0] if '@giki.edu.pk' in email else email
                
                user = User(
                    email=email,
                    name=user_info['displayName'],
                    roll_number=roll_number,
                    outlook_token=outlook_manager.access_token
                )
                db.session.add(user)
            else:
                user.outlook_token = outlook_manager.access_token
            
            db.session.commit()
            session['user_id'] = user.id
            session['user_email'] = user.email
            flash(f'Welcome, {user.name}!', 'success')
            return redirect(url_for('dashboard'))
    
    flash('Authentication failed', 'error')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    """Main dashboard"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    return render_template('dashboard.html', user=user)

@app.route('/complaints')
def complaints():
    """Complaint management page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    user_complaints = Complaint.query.filter_by(user_id=user.id).order_by(Complaint.created_at.desc()).all()
    return render_template('complaints.html', user=user, complaints=user_complaints)

@app.route('/api/complaint', methods=['POST'])
def create_complaint():
    """Create new complaint"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    description = data.get('description', '')
    
    if not description:
        return jsonify({'error': 'Description is required'}), 400
    
    # Process complaint with AI
    categorization = complaint_processor.categorize_complaint(description)
    relevant_contacts = complaint_processor.find_relevant_contacts(categorization['category'])
    
    # Create complaint
    complaint = Complaint(
        user_id=session['user_id'],
        category=categorization['category'],
        subcategory=categorization.get('subcategory'),
        description=description,
        urgency=categorization['urgency']
    )
    
    db.session.add(complaint)
    db.session.commit()
    
    return jsonify({
        'complaint_id': complaint.id,
        'category': categorization['category'],
        'urgency': categorization['urgency'],
        'contacts': relevant_contacts
    })

@app.route('/navigation')
def navigation():
    """Campus navigation page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    return render_template('navigation.html')

@app.route('/api/search_location')
def search_location():
    """Search for campus locations"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    query = request.args.get('q', '')
    results = campus_navigator.search_location(query)
    
    return jsonify({'results': results})

@app.route('/api/directions')
def get_directions():
    """Get directions between locations"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    from_lat = float(request.args.get('from_lat'))
    from_lng = float(request.args.get('from_lng'))
    to_lat = float(request.args.get('to_lat'))
    to_lng = float(request.args.get('to_lng'))
    
    directions = campus_navigator.get_directions(from_lat, from_lng, to_lat, to_lng)
    
    return jsonify(directions)

@app.route('/food')
def food():
    """Food ordering page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    restaurants = food_system.get_restaurants()
    return render_template('food.html', restaurants=restaurants)

@app.route('/api/restaurant/<int:restaurant_id>/menu')
def get_menu(restaurant_id):
    """Get restaurant menu"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    menu = food_system.get_menu(restaurant_id)
    return jsonify({'menu': menu})

@app.route('/api/order', methods=['POST'])
def create_order():
    """Create food order"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    result = food_system.create_order(
        user_id=session['user_id'],
        restaurant_id=data['restaurant_id'],
        items=data['items'],
        delivery_location=data.get('delivery_location'),
        special_instructions=data.get('special_instructions')
    )
    
    if 'error' in result:
        return jsonify(result), 400
    
    return jsonify(result)

@app.route('/api/outlook/emails')
def get_outlook_emails():
    """Get Outlook emails"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.outlook_token:
        return jsonify({'error': 'Not connected to Outlook'}), 400
    
    # Set token and fetch emails
    outlook_manager.access_token = user.outlook_token
    emails = outlook_manager.get_emails(max_emails=50, days_back=7)
    
    return jsonify({'emails': emails})

@app.route('/api/outlook/send', methods=['POST'])
def send_outlook_email():
    """Send email via Outlook"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    user = User.query.get(session['user_id'])
    
    if not user.outlook_token:
        return jsonify({'error': 'Not connected to Outlook'}), 400
    
    outlook_manager.access_token = user.outlook_token
    success = outlook_manager.send_email(
        to_recipients=data['to'],
        subject=data['subject'],
        body=data['body'],
        cc_recipients=data.get('cc', [])
    )
    
    if success:
        return jsonify({'success': True})
    else:
        return jsonify({'error': 'Failed to send email'}), 500

# Initialize database
@app.before_first_request
def init_db():
    """Initialize database with sample data"""
    db.create_all()
    
    # Add sample department contacts
    if not DepartmentContact.query.first():
        contacts = [
            DepartmentContact(
                name='Dr. Ahmed Khan',
                department='Academic Affairs',
                designation='Dean Academic Affairs',
                email='dean.academic@giki.edu.pk',
                phone='053-1234567',
                office_location='Admin Building, Room 101'
            ),
            DepartmentContact(
                name='Mr. Ali Hassan',
                department='Hostel Management',
                designation='Hostel Warden',
                email='warden.male@giki.edu.pk',
                phone='053-7654321',
                office_location='Hostel A, Ground Floor'
            ),
            DepartmentContact(
                name='Ms. Sarah Ahmed',
                department='IT Department',
                designation='Network Administrator',
                email='it.support@giki.edu.pk',
                phone='053-9876543',
                office_location='Computer Lab Building'
            ),
            DepartmentContact(
                name='Mr. Omar Farooq',
                department='Maintenance',
                designation='Maintenance Supervisor',
                email='maintenance@giki.edu.pk',
                phone='053-2468135',
                office_location='Engineering Workshop'
            )
        ]
        
        for contact in contacts:
            db.session.add(contact)
    
    # Add sample campus locations
    if not CampusLocation.query.first():
        locations = [
            CampusLocation(
                name='Computer Lab 1',
                category='lab',
                building='CS Department',
                floor='1st',
                latitude=33.7840,
                longitude=72.3742,
                description='Main computer laboratory',
                keywords='["computer", "lab", "programming", "cs"]'
            ),
            CampusLocation(
                name='Lecture Hall A',
                category='classroom',
                building='Academic Block',
                floor='Ground',
                latitude=33.7841,
                longitude=72.3743,
                description='Large lecture hall for 200 students',
                keywords='["lecture", "hall", "classroom", "a"]'
            ),
            CampusLocation(
                name='Library',
                category='library',
                building='Library Building',
                floor='Multiple',
                latitude=33.7842,
                longitude=72.3744,
                description='Main campus library',
                keywords='["library", "study", "books", "reading"]'
            ),
            CampusLocation(
                name='Mess Hall',
                category='mess',
                building='Student Center',
                floor='Ground',
                latitude=33.7843,
                longitude=72.3745,
                description='Main dining hall',
                keywords='["mess", "food", "dining", "cafeteria"]'
            )
        ]
        
        for location in locations:
            db.session.add(location)
    
    # Add sample restaurants
    if not Restaurant.query.first():
        restaurants = [
            Restaurant(
                name='Main Mess',
                category='mess',
                location='Student Center',
                phone='053-1111111'
            ),
            Restaurant(
                name='GIKI Cafe',
                category='cafe',
                location='Academic Block',
                phone='053-2222222'
            ),
            Restaurant(
                name='TUC Food Court',
                category='tuc',
                location='Student Union Building',
                phone='053-3333333'
            )
        ]
        
        for restaurant in restaurants:
            db.session.add(restaurant)
            db.session.flush()  # Get ID without committing
            
            # Add sample menu items
            menu_items = [
                MenuItem(
                    restaurant_id=restaurant.id,
                    name='Biryani',
                    description='Traditional chicken biryani',
                    price=150.0,
                    category='main',
                    preparation_time=15
                ),
                MenuItem(
                    restaurant_id=restaurant.id,
                    name='Karhi',
                    description='Traditional karhi with rice',
                    price=120.0,
                    category='main',
                    preparation_time=10
                ),
                MenuItem(
                    restaurant_id=restaurant.id,
                    name='Tea',
                    description='Hot chai tea',
                    price=30.0,
                    category='beverage',
                    preparation_time=5
                )
            ]
            
            for item in menu_items:
                db.session.add(item)
    
    db.session.commit()
    print("Database initialized with sample data!")

if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)

# Additional API Endpoints
@app.route('/api/dashboard/stats')
def dashboard_stats():
    """Get dashboard statistics"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.get(session['user_id'])
    
    # Get email count
    email_count = 0
    if user.outlook_token:
        outlook_manager.access_token = user.outlook_token
        try:
            emails = outlook_manager.get_emails(max_emails=50, days_back=7)
            email_count = len([e for e in emails if not e.get('isRead', True)])
        except:
            pass
    
    # Get complaint stats
    active_complaints = Complaint.query.filter_by(user_id=user.id, status='pending').count()
    
    # Get order stats
    pending_orders = Order.query.filter_by(user_id=user.id, status='pending').count()
    
    return jsonify({
        'emails': email_count,
        'complaints': active_complaints,
        'orders': pending_orders
    })

@app.route('/api/complaints/<int:complaint_id>/escalate', methods=['POST'])
def escalate_complaint(complaint_id):
    """Escalate a complaint"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    complaint = Complaint.query.get_or_404(complaint_id)
    if complaint.user_id != session['user_id']:
        return jsonify({'error': 'Forbidden'}), 403
    
    complaint.urgency = 'high'
    complaint.status = 'in_progress'
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Complaint escalated'})

@app.route('/api/orders/<int:order_id>/status')
def order_status(order_id):
    """Get order status"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    order = Order.query.get_or_404(order_id)
    if order.user_id != session['user_id']:
        return jsonify({'error': 'Forbidden'}), 403
    
    # Calculate progress based on status
    progress_map = {
        'pending': 25,
        'preparing': 50,
        'ready': 75,
        'delivered': 100
    }
    
    steps = [
        {'name': 'Order received', 'completed': True},
        {'name': 'Preparing', 'completed': order.status in ['preparing', 'ready', 'delivered']},
        {'name': 'Out for delivery', 'completed': order.status in ['ready', 'delivered']},
        {'name': 'Delivered', 'completed': order.status == 'delivered'}
    ]
    
    return jsonify({
        'progress': progress_map.get(order.status, 0),
        'steps': steps,
        'status': order.status,
        'estimated_delivery': order.estimated_delivery.isoformat() if order.estimated_delivery else None
    })

@app.route('/api/notifications')
def get_notifications():
    """Get user notifications"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    # Get recent notifications (mock data for now)
    notifications = [
        {'id': 1, 'message': 'Your complaint has been received', 'type': 'info', 'time': '2024-01-15 10:30'},
        {'id': 2, 'message': 'Order delivered successfully', 'type': 'success', 'time': '2024-01-15 12:15'}
    ]
    
    return jsonify({'notifications': notifications})

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return jsonify({'error': 'Internal server error'}), 500

# Health check endpoint
@app.route('/health')
def health_check():
    return jsonify({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()})

if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
